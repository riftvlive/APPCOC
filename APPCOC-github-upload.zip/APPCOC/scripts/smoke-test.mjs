const baseUrl = process.env.APP_URL || 'https://android.riftv.net';

const request = async (path, options = {}) => {
  const response = await fetch(`${baseUrl}${path}`, options);
  const body = await response.text();
  let data;
  try { data = JSON.parse(body); } catch { data = body; }
  return { response, data };
};

const cookieFrom = response => response.headers.get('set-cookie')?.split(';')[0] || '';
const assert = (condition, message) => {
  if (!condition) throw new Error(message);
};

const health = await request('/api/health');
assert(health.response.ok && health.data.database === 'connected', 'health/database check failed');

const unauthenticated = await request('/api/state');
assert(unauthenticated.response.status === 401, 'unauthenticated state access was not rejected');

const adminLogin = await request('/api/auth/login', {
  method: 'POST', headers: { 'content-type': 'application/json' },
  body: JSON.stringify({ phone: '0610187970', password: '7970' })
});
assert(adminLogin.response.ok && adminLogin.data.user?.role === 'admin', 'admin login failed');
const adminCookie = cookieFrom(adminLogin.response);

const workerLogin = await request('/api/auth/login', {
  method: 'POST', headers: { 'content-type': 'application/json' },
  body: JSON.stringify({ phone: '0664455667', password: '5667' })
});
assert(workerLogin.response.ok && workerLogin.data.user?.role === 'worker', 'worker login failed');

const workerCookie = cookieFrom(workerLogin.response);
const workerAudit = await request('/api/audit', {
  method: 'POST', headers: { cookie: workerCookie, 'content-type': 'application/json' },
  body: JSON.stringify({ entry: { action: 'create', entityType: 'smoke_test', details: 'اختبار آلي' } })
});
assert(workerAudit.response.status === 201, 'worker audit append failed');
const workerSync = await request('/api/sync', {
  method: 'POST', headers: { cookie: workerCookie, 'content-type': 'application/json' },
  body: JSON.stringify({ localChanges: [] })
});
assert(workerSync.response.status === 403, 'worker sync access was not rejected');

const workerState = await request('/api/state', { headers: { cookie: workerCookie } });
assert(workerState.response.ok, 'worker state access failed');
assert(Array.isArray(workerState.data.auditLogs) && workerState.data.auditLogs.length === 0, 'audit logs leaked to worker');
assert(Array.isArray(workerState.data.users) && workerState.data.users.length === 1, 'user directory leaked to worker');

const adminState = await request('/api/state', { headers: { cookie: adminCookie } });
assert(adminState.response.ok && adminState.data.auditLogs.some(log => log.details === 'اختبار آلي'), 'audit event was not persisted');

console.log(`Smoke tests passed for ${baseUrl}`);
