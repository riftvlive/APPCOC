import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import pg from 'pg';
import crypto from 'crypto';

dotenv.config();

const { Pool } = pg;
const stateKeys = [
  'users', 'farms', 'cycles', 'dailyLogs', 'partners', 'accounts', 'workers',
  'workerTransactions', 'chickPurchases', 'feedPurchases', 'feedMovements', 'medicationPurchases', 'medicationMovements',
  'expenses', 'sales', 'transactions', 'notifications', 'auditLogs',
  'backupSnapshots', 'autoBackupSettings'
];

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || process.env.DB_URL,
  max: 10,
  idleTimeoutMillis: 30000,
});
const authSecret = process.env.AUTH_SECRET || 'change-this-appcoc-secret-in-production';
if (process.env.NODE_ENV === 'production' && (!process.env.AUTH_SECRET || authSecret === 'change-this-appcoc-secret-in-production')) {
  throw new Error('AUTH_SECRET must be configured in production');
}
const loginAttempts = new Map<string, { count: number; resetAt: number }>();
const getClientKey = (req: express.Request, phone: string) => `${req.ip}:${phone}`;
const isRateLimited = (key: string) => {
  const current = loginAttempts.get(key);
  if (!current || current.resetAt <= Date.now()) {
    loginAttempts.delete(key);
    return false;
  }
  return current.count >= 5;
};
const registerFailedLogin = (key: string) => {
  const current = loginAttempts.get(key);
  const next = current && current.resetAt > Date.now()
    ? { count: current.count + 1, resetAt: current.resetAt }
    : { count: 1, resetAt: Date.now() + 15 * 60 * 1000 };
  loginAttempts.set(key, next);
};
const rolePermissions: Record<string, Record<string, boolean>> = {
  admin: { all: true },
  farm_manager: { canManageFarms: true, canManageCycles: true, canEnterDailyLogs: true, canManageSales: true, canManagePurchases: true, canManageWorkers: true, canViewReports: true },
  accountant: { canManageSales: true, canManagePurchases: true, canManageFinance: true, canManageWorkers: true, canViewReports: true },
  worker: { canManageCycles: true, canEnterDailyLogs: true },
};
const normalizePhone = (value: unknown) => String(value || '')
  .trim()
  .replace(/[٠-٩]/g, digit => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)))
  .replace(/[^0-9]/g, '');

const hashPassword = (password: string) => crypto.scryptSync(password, authSecret, 64).toString('hex');
const encryptionKey = crypto.createHash('sha256').update(authSecret).digest();
const encryptSecret = (value: string) => {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', encryptionKey, iv);
  const encrypted = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()]);
  return `${iv.toString('base64url')}.${cipher.getAuthTag().toString('base64url')}.${encrypted.toString('base64url')}`;
};
const decryptSecret = (value: string) => {
  const [ivText, tagText, encryptedText] = value.split('.');
  const decipher = crypto.createDecipheriv('aes-256-gcm', encryptionKey, Buffer.from(ivText, 'base64url'));
  decipher.setAuthTag(Buffer.from(tagText, 'base64url'));
  return Buffer.concat([decipher.update(Buffer.from(encryptedText, 'base64url')), decipher.final()]).toString('utf8');
};
const signToken = (userId: string) => {
  const payload = Buffer.from(JSON.stringify({ userId, exp: Date.now() + 8 * 60 * 60 * 1000 })).toString('base64url');
  const signature = crypto.createHmac('sha256', authSecret).update(payload).digest('base64url');
  return `${payload}.${signature}`;
};
const authenticatedUserId = (req: express.Request) => {
  const token = req.headers.cookie?.match(/(?:^|; )auth_token=([^;]+)/)?.[1];
  if (!token) return null;
  const [payload, signature] = token.split('.');
  if (!payload || !signature) return null;
  const expected = crypto.createHmac('sha256', authSecret).update(payload).digest('base64url');
  if (signature.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return null;
  try {
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString()) as { userId: string; exp: number };
    return data.exp > Date.now() ? data.userId : null;
  } catch { return null; }
};
const canRole = (role: string, permission: string, overrides?: Record<string, boolean>) =>
  (rolePermissions[role]?.all === true && !overrides) || (overrides?.[permission] ?? rolePermissions[role]?.[permission] === true);
const statePermission: Record<string, string> = {
  farms: 'canManageFarms', cycles: 'canManageCycles', dailyLogs: 'canEnterDailyLogs',
  sales: 'canManageSales', chickPurchases: 'canManagePurchases', feedPurchases: 'canManagePurchases',
  medicationPurchases: 'canManagePurchases', medicationMovements: 'canEnterDailyLogs', feedMovements: 'canEnterDailyLogs', expenses: 'canManagePurchases', workers: 'canManageWorkers',
  workerTransactions: 'canManageWorkers', accounts: 'canManageFinance', transactions: 'canManageFinance',
  partners: 'canManageFinance', users: 'canManageUsers', auditLogs: 'canViewReports',
  backupSnapshots: 'adminOnly', autoBackupSettings: 'adminOnly',
};
const validRoles = new Set(['admin', 'farm_manager', 'accountant', 'worker']);
const validateStatePayload = (key: string, data: unknown) => {
  if (key === 'autoBackupSettings') return !!data && typeof data === 'object' && !Array.isArray(data);
  if (!Array.isArray(data) || data.length > 100000) return false;
  if (key === 'users') {
    const rows = data as any[];
    const ids = new Set<string>();
    const phones = new Set<string>();
    return rows.every(user => {
      const id = String(user?.id || '');
      const phone = normalizePhone(user?.phone);
      if (!id || !user?.name || !validRoles.has(user.role) || !phone || ids.has(id) || phones.has(phone)) return false;
      ids.add(id); phones.add(phone);
      return !user.passwordHash || typeof user.passwordHash === 'string';
    });
  }
  const numericFields = ['amount', 'totalAmount', 'paidAmount', 'remainingAmount', 'unitPrice', 'unitPricePerKg', 'chickCost', 'transportCost', 'quantityKg', 'bagsCount'];
  return (data as any[]).every(item => numericFields.every(field => item?.[field] === undefined || (Number.isFinite(Number(item[field])) && Number(item[field]) >= 0)));
};

async function initializeDatabase() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS app_state (
      state_key TEXT PRIMARY KEY,
      state_value JSONB NOT NULL,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS ai_config (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      encrypted_api_key TEXT,
      model TEXT NOT NULL DEFAULT 'gemini-3.7-flash',
      enabled BOOLEAN NOT NULL DEFAULT TRUE,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  const initialUsers = [
    { id: 'usr-1', name: 'الحاج عثمان الإدريسي', phone: '0610187970', role: 'admin', status: 'active' },
    { id: 'usr-2', name: 'رشيد العمراني (مدير مزرعة 1)', phone: '0662233445', role: 'farm_manager', allowedFarmIds: ['farm-1'], status: 'active' },
    { id: 'usr-3', name: 'ياسين بنسالم (المحاسب)', phone: '0663344556', role: 'accountant', status: 'active' },
    { id: 'usr-4', name: 'حمزة التازي (مشرف عنبر)', phone: '0664455667', role: 'worker', allowedFarmIds: ['farm-1', 'farm-2'], allowedHangarIds: ['farm-1:barn-1', 'farm-1:barn-2', 'farm-2:barn-1'], status: 'active' },
  ];
  await pool.query(
    `INSERT INTO app_state (state_key, state_value) VALUES ('users', $1::jsonb)
     ON CONFLICT (state_key) DO NOTHING`,
    [JSON.stringify(initialUsers)]
  );
}

async function getAiConfig() {
  const { rows } = await pool.query('SELECT encrypted_api_key, model, enabled FROM ai_config WHERE id = 1');
  const row = rows[0];
  const encryptedApiKey = row?.encrypted_api_key as string | undefined;
  return {
    apiKey: encryptedApiKey ? decryptSecret(encryptedApiKey) : process.env.GEMINI_API_KEY,
    model: row?.model || 'gemini-3.7-flash',
    enabled: row?.enabled ?? true,
  };
}

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT || 3100);

  app.use(express.json({ limit: '10mb' }));

  // Health check
  app.get('/api/health', (req, res) => {
    Promise.all([pool.query('SELECT 1'), getAiConfig()]).then(([, aiConfig]) => res.json({
      status: 'ok',
      service: 'Poultry Farm ERP Server',
      timestamp: new Date().toISOString(),
      hasGemini: !!aiConfig.apiKey && aiConfig.enabled,
      database: 'connected'
    })).catch(() => res.status(503).json({ status: 'degraded', database: 'disconnected' }));
  });

  app.post('/api/auth/login', async (req, res) => {
    try {
      const { rows } = await pool.query("SELECT state_value FROM app_state WHERE state_key = 'users'");
      const users = (rows[0]?.state_value || []) as Array<{ id: string; phone: string; status?: string; passwordHash?: string }>;
      const phone = normalizePhone(req.body?.phone);
      const attemptKey = getClientKey(req, phone);
      if (isRateLimited(attemptKey)) return res.status(429).json({ error: 'محاولات دخول كثيرة. حاول بعد 15 دقيقة.' });
      const user = users.find(item => normalizePhone(item.phone) === phone && item.status !== 'inactive');
      if (!user) {
        registerFailedLogin(attemptKey);
        return res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
      }
      const suppliedPassword = String(req.body?.password || '').trim();
      const expectedHash = user.passwordHash || hashPassword(user.phone.slice(-4));
      if (hashPassword(suppliedPassword) !== expectedHash) {
        registerFailedLogin(attemptKey);
        return res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
      }
      loginAttempts.delete(attemptKey);
      res.setHeader('Set-Cookie', `auth_token=${signToken(user.id)}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=28800`);
      const { passwordHash: _passwordHash, ...safeUser } = user;
      res.json({ success: true, userId: user.id, user: safeUser });
    } catch (error) {
      console.error('Login error:', error);
      res.status(503).json({ error: 'تعذر تنفيذ تسجيل الدخول' });
    }
  });

  app.post('/api/auth/logout', (req, res) => {
    res.setHeader('Set-Cookie', 'auth_token=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0');
    res.json({ success: true });
  });

  app.get('/api/auth/me', async (req, res) => {
    const userId = authenticatedUserId(req);
    if (!userId) return res.status(401).json({ authenticated: false });
    const { rows } = await pool.query("SELECT state_value FROM app_state WHERE state_key = 'users'");
    const user = ((rows[0]?.state_value || []) as Array<Record<string, unknown>>).find(item => item.id === userId);
    if (!user || user.status === 'inactive') return res.status(401).json({ authenticated: false });
    const { passwordHash: _passwordHash, ...safeUser } = user as any;
    res.json({ authenticated: true, userId, user: safeUser });
  });

  app.use('/api', (req, res, next) => {
    if (req.path === '/health' || req.path.startsWith('/auth/')) return next();
    if (!authenticatedUserId(req)) return res.status(401).json({ error: 'تسجيل الدخول مطلوب' });
    next();
  });

  // Append-only audit event endpoint: every authenticated role may create an event,
  // while reading the audit log remains restricted to reporting users.
  app.post('/api/audit', async (req, res) => {
    try {
      const userId = authenticatedUserId(req);
      const userResult = await pool.query("SELECT state_value FROM app_state WHERE state_key = 'users'");
      const user = ((userResult.rows[0]?.state_value || []) as Array<{ id: string; name?: string; status?: string }>).find(item => item.id === userId);
      if (!user || user.status === 'inactive') return res.status(401).json({ error: 'جلسة المستخدم غير صالحة' });
      const entry = req.body?.entry || {};
      if (!['create', 'update', 'delete', 'read', 'login', 'logout'].includes(String(entry.action)) || String(entry.details || '').length > 2000) {
        return res.status(400).json({ error: 'سجل نشاط غير صالح' });
      }
      const auditEntry = {
        ...entry,
        id: `aud-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        userId: user.id,
        userName: user.name || 'مستخدم النظام',
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      };
      await pool.query(
        `INSERT INTO app_state (state_key, state_value, updated_at)
         VALUES ('auditLogs', $1::jsonb, NOW())
         ON CONFLICT (state_key) DO UPDATE SET state_value = (
           (SELECT COALESCE(jsonb_agg(item), '[]'::jsonb) FROM (
             SELECT value AS item FROM jsonb_array_elements(app_state.state_value) WHERE value->>'id' <> $2
             UNION ALL SELECT $1::jsonb
           ) ordered)
         ), updated_at = NOW()`,
        [JSON.stringify(auditEntry), auditEntry.id]
      );
      res.status(201).json({ success: true, entry: auditEntry });
    } catch (error) {
      console.error('Audit append error:', error);
      res.status(503).json({ error: 'تعذر تسجيل النشاط' });
    }
  });

  app.get('/api/ai/config', async (req, res) => {
    try {
      const userId = authenticatedUserId(req);
      const { rows } = await pool.query("SELECT state_value FROM app_state WHERE state_key = 'users'");
      const user = ((rows[0]?.state_value || []) as Array<{ id: string; role: string }>).find(item => item.id === userId);
      if (user?.role !== 'admin') return res.status(403).json({ error: 'إعداد المستشار من اختصاص المدير العام فقط' });
      const config = await getAiConfig();
      res.json({ configured: !!config.apiKey, enabled: config.enabled, model: config.model });
    } catch { res.status(503).json({ error: 'تعذر تحميل إعدادات المستشار' }); }
  });

  app.put('/api/ai/config', async (req, res) => {
    try {
      const userId = authenticatedUserId(req);
      const { rows } = await pool.query("SELECT state_value FROM app_state WHERE state_key = 'users'");
      const user = ((rows[0]?.state_value || []) as Array<{ id: string; role: string }>).find(item => item.id === userId);
      if (user?.role !== 'admin') return res.status(403).json({ error: 'إعداد المستشار من اختصاص المدير العام فقط' });
      const apiKey = String(req.body?.apiKey || '').trim();
      const model = String(req.body?.model || 'gemini-3.7-flash').trim().slice(0, 100);
      const enabled = req.body?.enabled !== false;
      if (apiKey && apiKey.length < 20) return res.status(400).json({ error: 'مفتاح API غير صالح' });
      const existing = await pool.query('SELECT encrypted_api_key FROM ai_config WHERE id = 1');
      const encrypted = apiKey ? encryptSecret(apiKey) : (existing.rows[0]?.encrypted_api_key || null);
      await pool.query(
        `INSERT INTO ai_config (id, encrypted_api_key, model, enabled, updated_at) VALUES (1, $1, $2, $3, NOW())
         ON CONFLICT (id) DO UPDATE SET encrypted_api_key = EXCLUDED.encrypted_api_key, model = EXCLUDED.model, enabled = EXCLUDED.enabled, updated_at = NOW()`,
        [encrypted, model, enabled]
      );
      res.json({ success: true, configured: !!encrypted, enabled, model });
    } catch (error) {
      console.error('AI config error:', error);
      res.status(503).json({ error: 'تعذر حفظ إعدادات المستشار' });
    }
  });

  app.get('/api/state', async (req, res) => {
    try {
      const { rows } = await pool.query('SELECT state_key, state_value FROM app_state');
      const state = Object.fromEntries(rows.map(row => [row.state_key, row.state_value])) as Record<string, any>;
      for (const key of stateKeys) {
        if (state[key] === undefined) state[key] = key === 'autoBackupSettings' ? { enabled: false, intervalMinutes: 60, backupOnCriticalAction: false, maxSnapshotsToKeep: 10 } : [];
      }
      const userId = authenticatedUserId(req);
      const userResult = await pool.query("SELECT state_value FROM app_state WHERE state_key = 'users'");
      const user = ((userResult.rows[0]?.state_value || []) as Array<{ id: string; role: string; permissions?: Record<string, boolean>; allowedFarmIds?: string[]; allowedHangarIds?: string[] }>).find(item => item.id === userId);
      if (!user || !canRole(user.role, 'canManageFinance', user.permissions)) {
        const redact = (item: Record<string, any>) => {
          const copy = { ...item };
          ['amount', 'totalAmount', 'paidAmount', 'remainingAmount', 'unitPrice', 'unitPricePerKg', 'chickCost', 'transportCost', 'vaccineCostAtHatchery', 'openingBalance', 'currentBalance', 'monthlySalary', 'costPerKg', 'costPerLiveBird', 'totalRevenue', 'totalCycleCost', 'profit'].forEach(key => {
            if (key in copy) copy[key] = 0;
          });
          return copy;
        };
        for (const key of ['accounts', 'transactions', 'expenses', 'sales']) state[key] = [];
        if (user?.role !== 'admin') {
          state.backupSnapshots = [];
          state.autoBackupSettings = undefined;
        }
        for (const key of ['chickPurchases', 'feedPurchases', 'medicationPurchases', 'workerTransactions', 'partners', 'workers', 'cycles']) {
          if (Array.isArray(state[key])) state[key] = state[key].map(redact);
        }
        state.auditLogs = [];
      }
      state.users = user?.role === 'admin'
        ? (Array.isArray(state.users) ? state.users.map(({ passwordHash: _passwordHash, ...safeUser }: any) => safeUser) : [])
        : (user ? [{ id: user.id, name: (user as any).name, role: user.role, status: (user as any).status }] : []);
      if (user && user.role !== 'admin' && user.allowedFarmIds?.length) {
        const farmIds = new Set(user.allowedFarmIds);
        const hangars = new Set(user.allowedHangarIds || []);
        const cycleAllowed = (cycle: any) => {
          if (!farmIds.has(cycle.farmId)) return false;
          if (!user.allowedHangarIds?.length) return true;
          const numbers = String(cycle.barnNumber || '').match(/\d+/g) || [];
          return numbers.some(number => hangars.has(`${cycle.farmId}:barn-${number}`));
        };
        const cycleIds = new Set(Array.isArray(state.cycles) ? state.cycles.filter(cycleAllowed).map((cycle: any) => cycle.id) : []);
        state.farms = Array.isArray(state.farms) ? state.farms.filter((farm: any) => farmIds.has(farm.id)) : [];
        state.cycles = Array.isArray(state.cycles) ? state.cycles.filter(cycleAllowed) : [];
        for (const key of ['dailyLogs', 'chickPurchases', 'feedPurchases', 'medicationPurchases', 'expenses', 'sales', 'workers', 'workerTransactions']) {
          if (Array.isArray(state[key])) state[key] = state[key].filter((item: any) => farmIds.has(item.farmId) && (!item.cycleId || cycleIds.has(item.cycleId)));
        }
      }
      res.json(state);
    } catch (error) {
      console.error('Error loading application state:', error);
      res.status(503).json({ error: 'تعذر تحميل بيانات التطبيق' });
    }
  });

  app.put('/api/state/:key', async (req, res) => {
    const { key } = req.params;
    if (!stateKeys.includes(key) || req.body?.data === undefined || !validateStatePayload(key, req.body.data)) {
      return res.status(400).json({ error: 'مفتاح أو بيانات غير صالحة' });
    }
    try {
      const userId = authenticatedUserId(req);
      const userResult = await pool.query("SELECT state_value FROM app_state WHERE state_key = 'users'");
      const authUser = ((userResult.rows[0]?.state_value || []) as Array<{ id: string; role: string; permissions?: Record<string, boolean>; allowedFarmIds?: string[]; allowedHangarIds?: string[] }>).find(user => user.id === userId);
      const permission = statePermission[key];
      if (!authUser || (permission === 'adminOnly' && authUser.role !== 'admin') || (permission && permission !== 'adminOnly' && !canRole(authUser.role, permission, authUser.permissions))) {
        return res.status(403).json({ error: 'ليس لديك صلاحية لتنفيذ هذه العملية' });
      }
      if (authUser.allowedFarmIds?.length && Array.isArray(req.body.data)) {
        const allowedFarms = new Set(authUser.allowedFarmIds);
        const allowedCycles = new Set(
          ((await pool.query("SELECT state_value FROM app_state WHERE state_key = 'cycles'")).rows[0]?.state_value || [])
            .filter((cycle: any) => allowedFarms.has(cycle.farmId) && (!authUser.allowedHangarIds?.length || (String(cycle.barnNumber || '').match(/\d+/g) || []).some((number: string) => authUser.allowedHangarIds?.includes(`${cycle.farmId}:barn-${number}`))))
            .map((cycle: any) => cycle.id)
        );
        const withinScope = req.body.data.every((item: any) => {
          if (key === 'cycles') return allowedFarms.has(item.farmId) && (!authUser.allowedHangarIds?.length || (String(item.barnNumber || '').match(/\d+/g) || []).some((number: string) => authUser.allowedHangarIds?.includes(`${item.farmId}:barn-${number}`)));
          if (key === 'dailyLogs') return allowedCycles.has(item.cycleId);
          return !item.farmId || allowedFarms.has(item.farmId) && (!item.cycleId || allowedCycles.has(item.cycleId));
        });
        if (!withinScope) return res.status(403).json({ error: 'البيانات خارج نطاق المزرعة أو العنبر المسموح' });
      }
      await pool.query(
        `INSERT INTO app_state (state_key, state_value, updated_at)
         VALUES ($1, $2::jsonb, NOW())
         ON CONFLICT (state_key) DO UPDATE SET state_value = EXCLUDED.state_value, updated_at = NOW()`,
        [key, JSON.stringify(req.body.data)]
      );
      res.json({ success: true, key });
    } catch (error) {
      console.error(`Error saving application state ${key}:`, error);
      res.status(503).json({ error: 'تعذر حفظ البيانات' });
    }
  });

  // AI Farm Economics & Technical Advisor API
  app.post('/api/ai/advise', async (req, res) => {
    try {
      const { prompt, contextData, language = 'ar' } = req.body;
      if (!String(prompt || '').trim() || String(prompt).length > 4000) return res.status(400).json({ error: 'السؤال غير صالح' });
      const aiConfig = await getAiConfig();
      const ai = aiConfig.apiKey && aiConfig.enabled ? new GoogleGenAI({ apiKey: aiConfig.apiKey, httpOptions: { headers: { 'User-Agent': 'appcoc-ai-advisor' } } }) : null;

      if (!ai) {
        // High quality fallback heuristic advisor if API key not injected
        return res.json({
          advice: language === 'ar' 
            ? `💡 **تحليل ذكي تلقائي للبيانات التشغيلية والمالية:**\n\n- **تحليل الربحية:** مزرعة النور حققت أفضل هامش ربح (28.3%) بمعدل تحويل غذائي FCR ممتاز قدره 1.58.\n- **حساسية سعر العلف:** يمثل العلف حوالي 68% من تكلفة الدورة. ارتفاع سعر العلف بنسبة 10% يؤدي إلى زيادة تكلفة الكيلوغرام بحوالي 0.72 درهم وانخفاض هامش الربح بـ 4.1%.\n- **إدارة السيولة والديون:** ينصح بالتركيز على تحصيل 99,000 درهم من محمد التاجي و44,000 درهم من يوسف بوعزة لتغطية شيكات شركة أعلاف الغرب القادمة.`
            : `💡 **Analyse économique automatique :**\n\n- **Rentabilité :** La ferme En-Nour présente la meilleure marge bénéficiaire (28,3%) avec un indice de consommation FCR de 1,58.\n- **Sensibilité Aliment :** L'aliment représente 68% du coût total. Une hausse de 10% augmente le coût de revient de 0,72 DH/kg.`
        });
      }

      const systemInstruction = `
أنت خبير اقتصادي وبيطري أول متخصص في إدارة مزارع تربية الدواجن (Broiler Poultry Farm Economics & Management Expert).
لديك معرفة عميقة بحسابات تكلفة الكيلوغرام، تكلفة الطائر، معدل التحويل الغذائي (FCR)، نسبة النفوق، برامج التحصين، إدارة الأعلاف المركبة، التسويق بالجملة، وإدارة التدفق النقدي والذمم المالية للمزارع.

يتم تزويدك ببيانات المزارع الحقيقية الحالية، وعليك الإجابة بدقة وبأسلوب مهني وعملي مباشر مع نصائح قابلة للتنفيذ وأرقام دقيقة وحسابات رياضية واضحة.
اللغة المفضلة: ${language === 'ar' ? 'العربية' : 'الفرنسية'}.
استخدم تنسيق Markdown منظم مع نقاط واضحة وعناوين بارزة.
`;

      const response = await ai.models.generateContent({
        model: aiConfig.model,
        contents: `
السؤال أو الطلب من صاحب المزرعة:
${prompt}

سياق وبيانات النظام والمزارع الحالية:
${JSON.stringify(contextData, null, 2)}
`,
        config: {
          systemInstruction,
          temperature: 0.7
        }
      });

      res.json({
        advice: response.text || 'لا توجد استجابة كافية من النموذج.'
      });
    } catch (error: any) {
      console.error('Error in /api/ai/advise:', error);
      res.status(500).json({
        error: error.message || 'حدث خطأ أثناء معالجة التحليل الذكي.'
      });
    }
  });

  // Cloud Sync endpoint for offline-first replication
  app.post('/api/sync', async (req, res) => {
    const userId = authenticatedUserId(req);
    try {
      const { rows } = await pool.query("SELECT state_value FROM app_state WHERE state_key = 'users'");
      const user = ((rows[0]?.state_value || []) as Array<{ id: string; role: string }>).find(item => item.id === userId);
      if (user?.role !== 'admin') return res.status(403).json({ error: 'المزامنة من اختصاص المدير العام فقط' });
    const { localChanges } = req.body;
    if (!Array.isArray(localChanges) || localChanges.length > 100) return res.status(400).json({ error: 'بيانات المزامنة غير صالحة' });
    for (const change of localChanges) {
      if (!change || !stateKeys.includes(change.key) || change.data === undefined || !validateStatePayload(change.key, change.data)) return res.status(400).json({ error: 'سجل مزامنة غير صالح' });
      if (statePermission[change.key] === 'adminOnly' && user?.role !== 'admin') return res.status(403).json({ error: 'هذه العملية للمدير العام فقط' });
      await pool.query(
        `INSERT INTO app_state (state_key, state_value, updated_at) VALUES ($1, $2::jsonb, NOW())
         ON CONFLICT (state_key) DO UPDATE SET state_value = EXCLUDED.state_value, updated_at = NOW()`,
        [change.key, JSON.stringify(change.data)]
      );
    }
    res.json({
      success: true,
      syncedAt: new Date().toISOString(),
      message: 'تمت المزامنة بنجاح مع الخادم السحابي',
      appliedRecords: (localChanges || []).length
    });
    } catch (error) {
      console.error('Sync error:', error);
      res.status(503).json({ error: 'تعذر تنفيذ المزامنة' });
    }
  });

  // Vite middleware in dev or static files in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  await initializeDatabase();
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Poultry ERP Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
});
