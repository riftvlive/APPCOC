import React, { useState } from 'react';
import { LockKeyhole, Phone, LogIn, AlertCircle } from 'lucide-react';
import { User, UserRole } from '../../types';

interface LoginScreenProps {
  users: User[];
  onLogin: (user: User) => void;
  offlineMode?: boolean;
}

const roleLabel = (role: UserRole) => ({
  admin: 'المدير العام',
  farm_manager: 'مدير مزرعة',
  accountant: 'المحاسب',
  worker: 'مشرف / عامل'
}[role] || role);

export const LoginScreen: React.FC<LoginScreenProps> = ({ users, onLogin, offlineMode = false }) => {
  const [phone, setPhone] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    try {
      const response = await fetch('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ phone: phone.trim(), password: pin.trim() }) });
      if (!response.ok) return setError('رقم الهاتف أو رمز الدخول غير صحيح.');
      const result = await response.json() as { user?: User };
      const user = result.user || users.find(item => item.phone === phone.trim() && item.status !== 'inactive');
      if (!user) return setError('تعذر تحميل بيانات المستخدم.');
      setError('');
      onLogin(user);
      return;
    } catch {
      if (offlineMode) {
        const cachedUser = users.find(item => item.phone === phone.trim() && item.pin === pin.trim() && item.status !== 'inactive');
        if (cachedUser) {
          setError('');
          onLogin(cachedUser);
          return;
        }
      }
      return setError(offlineMode ? 'بيانات الدخول المحلية غير صحيحة.' : 'تعذر الاتصال بالخادم.');
    }
  };

  return (
    <main className="min-h-screen bg-stone-950 text-stone-100 flex items-center justify-center p-4" dir="rtl">
      <div className="w-full max-w-md bg-stone-900 border border-stone-800 rounded-3xl p-6 shadow-2xl">
        <div className="text-center mb-6">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-amber-500 text-stone-950 flex items-center justify-center text-3xl mb-3">🐔</div>
          <h1 className="text-xl font-black">تسجيل الدخول</h1>
          <p className="text-xs text-stone-400 mt-1">مزارعنا لإدارة مزارع الدواجن</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-stone-300 mb-1">المستخدم</label>
            <div className="relative"><Phone className="absolute right-3 top-2.5 w-4 h-4 text-stone-500" /><input required value={phone} onChange={e => setPhone(e.target.value)} placeholder="06XXXXXXXX" className="w-full bg-stone-800 border border-stone-700 rounded-xl p-2.5 pr-10 text-sm text-stone-100" /></div>
          </div>
          <div>
            <label className="block text-xs font-bold text-stone-300 mb-1">رمز الدخول</label>
            <div className="relative">
              <LockKeyhole className="absolute right-3 top-2.5 w-4 h-4 text-stone-500" />
              <input type="password" inputMode="numeric" maxLength={12} required value={pin} onChange={e => setPin(e.target.value)} placeholder="أدخل الرمز" className="w-full bg-stone-800 border border-stone-700 rounded-xl p-2.5 pr-10 text-sm text-stone-100" />
            </div>
          </div>
          {error && <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs font-bold"><AlertCircle className="w-4 h-4 shrink-0" />{error}</div>}
          <button type="submit" className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-stone-950 rounded-xl font-black flex items-center justify-center gap-2 transition"><LogIn className="w-4 h-4" />دخول إلى النظام</button>
        </form>
        <p className="text-center text-[11px] text-stone-500 mt-5">للحصول على رمز الدخول أو تغييره، تواصل مع المدير العام.</p>
      </div>
    </main>
  );
};
