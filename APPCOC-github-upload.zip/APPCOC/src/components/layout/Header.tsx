import React, { useState } from 'react';
import {
  Building2,
  Bell,
  Search,
  Wifi,
  WifiOff,
  X,
  AlertTriangle,
  Info,
  CheckCircle2,
  Check,
  Database
} from 'lucide-react';
import { useFarm } from '../../context/FarmContext';

interface HeaderProps {
  onOpenSearch: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenSearch, activeTab, setActiveTab }) => {
  const {
    farms,
    selectedFarmId,
    setSelectedFarmId,
    currentUser,
    notifications,
    markNotificationAsRead,
    clearAllNotifications,
    language,
    setLanguage,
    dataSource,
    isFarmAllowed
  } = useFarm();

  const [showNotifications, setShowNotifications] = useState(false);

  const unreadNotifs = notifications.filter(n => !n.isRead);
  const visibleFarms = farms.filter(farm => isFarmAllowed(farm.id));
  const canSeeAllFarms = currentUser.role === 'admin' || (!currentUser.allowedFarmIds || currentUser.allowedFarmIds.length === 0);

  return (
    <header className="sticky top-0 z-40 bg-stone-900 text-stone-100 border-b border-stone-800 shadow-md">
      <div className="w-full mx-auto px-2 sm:px-6 py-2.5 flex items-center justify-between gap-1 overflow-visible">
        {/* Brand & Farm Switcher */}
        <div className="flex items-center gap-1.5 sm:gap-3 min-w-0">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500 flex items-center justify-center text-stone-950 font-bold shadow-inner">
              <span className="text-xl">🐔</span>
            </div>
            <div className="hidden sm:block">
              <h1 className="text-base font-extrabold tracking-tight leading-tight text-white">
                {language === 'ar' ? 'مزارعنا للدواجن' : 'AvicoGestion ERP'}
              </h1>
              <p className="text-[11px] text-amber-400 font-medium">
                {language === 'ar' ? 'نظام إدارة مزارع التسمين المتكامل' : 'Système Avicole Intégré'}
              </p>
            </div>
          </div>

          {/* Farm Filter Dropdown */}
          <div className="relative min-w-0">
            <div className="flex items-center max-w-[170px] sm:max-w-none bg-stone-800/90 hover:bg-stone-700/90 border border-stone-700 text-xs rounded-lg px-1.5 sm:px-2.5 py-1.5 transition-colors">
              <Building2 className="w-3.5 h-3.5 text-amber-400 ml-1.5 shrink-0" />
              <select
                id="farm-filter-select"
                aria-label="تصفية المزرعة"
                value={selectedFarmId}
                onChange={(e) => setSelectedFarmId(e.target.value)}
                className="bg-transparent text-stone-200 text-xs font-semibold focus:outline-none cursor-pointer pr-1 max-w-[128px] sm:max-w-none truncate"
              >
                {canSeeAllFarms && <option value="all" className="bg-stone-800 text-stone-100">
                  {language === 'ar' ? '🏢 كل المزارع (النشاط بالكامل)' : '🏢 Toutes les fermes'}
                </option>}
                {visibleFarms.map((f) => (
                  <option key={f.id} value={f.id} className="bg-stone-800 text-stone-100">
                    📍 {f.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Right Tools: Sync status, Search, Notifications, Language, User/Role */}
        <div className="flex items-center gap-1 sm:gap-2.5 shrink-0">
          {/* Online/Offline Status */}
          <div
            className={`flex items-center gap-1 px-1.5 sm:px-2 py-1.5 sm:py-1 rounded-lg sm:rounded-full text-[11px] font-medium border ${
              dataSource === 'server'
                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800'
                : 'bg-amber-950/60 text-amber-300 border-amber-800'
            }`}
            title={dataSource === 'server' ? 'الخادم: البيانات محملة مباشرة من الخادم' : 'أوفلاين: يتم استخدام النسخة المحلية'}
            aria-label={dataSource === 'server' ? 'الخادم متصل' : 'وضع أوفلاين'}
          >
            {dataSource === 'server' ? <Wifi className="w-3 h-3 text-emerald-400" /> : <WifiOff className="w-3 h-3 text-amber-400" />}
          </div>

          {/* Auto Backup Vault Quick Chip */}
          {currentUser.role === 'admin' && <button
            onClick={() => setActiveTab('audit_backup')}
            className="flex items-center gap-1.5 px-1.5 sm:px-2.5 py-1.5 sm:py-1 rounded-lg sm:rounded-full text-[11px] font-bold border bg-stone-800/80 hover:bg-stone-700 text-stone-300 border-stone-700 cursor-pointer transition active:scale-95"
            title="النسخ التلقائي نشط — فتح النسخ الاحتياطي وقواعد البيانات"
            aria-label="النسخ التلقائي نشط"
          >
            <Database className="w-3.5 h-3.5 text-emerald-400" />
          </button>}

          {/* Universal Search Button */}
          <button
            id="header-search-btn"
            onClick={onOpenSearch}
            className="flex items-center gap-1.5 bg-stone-800 hover:bg-stone-700 text-stone-300 px-2 sm:px-2.5 py-1.5 rounded-lg text-xs transition border border-stone-700"
            title="بحث شامل (مزارع، دورات، زبناء، فواتير)"
          >
            <Search className="w-3.5 h-3.5 text-stone-400" />
            <span className="hidden lg:inline text-stone-400">{language === 'ar' ? 'بحث سريع...' : 'Recherche...'}</span>
            <kbd className="hidden lg:inline-block text-[10px] bg-stone-900 text-stone-400 px-1.5 py-0.5 rounded border border-stone-700">Ctrl+K</kbd>
          </button>

          {/* Notifications Trigger */}
          <div className="relative">
            <button
              id="header-notif-btn"
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 border border-stone-700 transition"
              aria-label="الإشعارات"
              aria-haspopup="dialog"
              aria-expanded={showNotifications}
            >
              <Bell className="w-4 h-4" />
              {unreadNotifs.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-rose-600 text-white font-bold text-[10px] w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
                  {unreadNotifs.length}
                </span>
              )}
            </button>

            {/* Notifications Dropdown Panel */}
            {showNotifications && (
              <div className="header-popover header-notification-popover fixed top-[4.25rem] left-1/2 -translate-x-1/2 w-[min(20rem,calc(100vw-1rem))] sm:absolute sm:top-auto sm:left-auto sm:right-0 sm:translate-x-0 sm:mt-2 sm:w-96 bg-stone-900 border border-stone-700 rounded-2xl shadow-2xl z-50 overflow-hidden">
                <div className="p-3.5 bg-stone-800/80 border-b border-stone-700 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Bell className="w-4 h-4 text-amber-400" />
                    <span className="font-bold text-sm text-stone-100">
                      {language === 'ar' ? 'التنبيهات والإشعارات' : 'Notifications'}
                    </span>
                    <span className="text-xs bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full font-semibold">
                      {unreadNotifs.length}
                    </span>
                  </div>
                  {unreadNotifs.length > 0 && (
                    <button
                      onClick={clearAllNotifications}
                      className="inline-flex items-center gap-1.5 text-xs text-stone-400 hover:text-amber-300 transition active:scale-95"
                      title="تعليم جميع الإشعارات كمقروءة"
                      aria-label="تعليم جميع الإشعارات كمقروءة"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">{language === 'ar' ? 'تعليم الكل كمقروء' : 'Tout marquer comme lu'}</span>
                    </button>
                  )}
                </div>

                <div className="max-h-80 overflow-y-auto divide-y divide-stone-800 p-1">
                  {notifications.length === 0 ? (
                    <div className="p-6 text-center text-xs text-stone-500">
                      {language === 'ar' ? 'لا توجد تنبيهات حالياً' : 'Aucune notification'}
                    </div>
                  ) : (
                    notifications.map((notif) => (
                      <div
                        key={notif.id}
                        onClick={() => {
                          markNotificationAsRead(notif.id);
                          if (notif.linkTab) setActiveTab(notif.linkTab);
                          setShowNotifications(false);
                        }}
                        role="button"
                        tabIndex={0}
                        onKeyDown={event => { if (event.key === 'Enter' || event.key === ' ') { markNotificationAsRead(notif.id); if (notif.linkTab) setActiveTab(notif.linkTab); setShowNotifications(false); } }}
                        className={`p-3 text-xs transition cursor-pointer hover:bg-stone-800/60 active:scale-[0.99] flex items-start gap-2.5 ${
                          notif.isRead ? 'opacity-60' : 'bg-stone-800/20'
                        }`}
                      >
                        <div className="mt-0.5 shrink-0">
                          <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${notif.type === 'danger' ? 'bg-rose-500/15' : notif.type === 'warning' ? 'bg-amber-500/15' : notif.type === 'info' ? 'bg-sky-500/15' : 'bg-emerald-500/15'}`}>
                            {notif.type === 'danger' && <AlertTriangle className="w-4 h-4 text-rose-500" />}
                            {notif.type === 'warning' && <AlertTriangle className="w-4 h-4 text-amber-400" />}
                            {notif.type === 'info' && <Info className="w-4 h-4 text-sky-400" />}
                            {notif.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-bold text-stone-200 mb-0.5">{notif.title}</div>
                          <p className="text-stone-400 text-[11px] leading-relaxed line-clamp-2">{notif.message}</p>
                          <span className="text-[10px] text-stone-500 mt-1 block">{notif.date}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Language Toggle */}
          <button
            id="header-lang-toggle"
            onClick={() => setLanguage(language === 'ar' ? 'fr' : 'ar')}
            className="flex items-center justify-center bg-stone-800 hover:bg-stone-700 text-stone-300 w-9 h-9 rounded-lg text-lg transition border border-stone-700 active:scale-95"
            title={language === 'ar' ? 'التبديل إلى الفرنسية' : 'Passer à l’arabe'}
            aria-label={language === 'ar' ? 'التبديل إلى الفرنسية' : 'Passer à l’arabe'}
          >
            <span aria-hidden="true">{language === 'ar' ? '🇫🇷' : '🇲🇦'}</span>
          </button>

        </div>
      </div>
    </header>
  );
};
