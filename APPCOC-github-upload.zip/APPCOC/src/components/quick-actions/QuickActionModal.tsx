import React, { useEffect, useState } from 'react';
import {
  X,
  PlusCircle,
  Receipt,
  ShoppingCart,
  ArrowDownLeft,
  Wheat,
  Pill,
  ArrowUpRight,
  UserCheck,
  Skull,
  Scale,
  ArrowLeftRight,
  CheckCircle2,
  AlertCircle,
  Egg
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useFarm } from '../../context/FarmContext';
import { getCycleDayNumber, getMoroccoDateISO } from '../../utils/date';
import { CHICK_BREEDS, PaymentMethod, UserPermissions } from '../../types';

interface QuickActionModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialAction?: string;
}

export const QuickActionModal: React.FC<QuickActionModalProps> = ({
  isOpen,
  onClose,
  initialAction
}) => {
  const {
    farms,
    cycles,
    partners,
    accounts,
    workers,
    medicationPurchases,
    medicationMovements,
    dailyLogs,
    allCycleSummaries,
    currency,
    language,
    addExpense,
    addSale,
    addFeedPurchase,
    addMedicationPurchase,
    addChickPurchase,
    addSettlementTransaction,
    addWorkerTransaction,
    addDailyLog,
    addAccountTransfer,
    hasPermission,
    selectedFarmId,
    isFarmAllowed
  } = useFarm();

  const [activeAction, setActiveAction] = useState<string>(initialAction || 'menu');
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Active cycles list for selecting in forms
  const activeCycles = cycles.filter(c => c.status !== 'completed');
  const defaultFarmId = selectedFarmId !== 'all' ? selectedFarmId : farms.find(farm => isFarmAllowed(farm.id))?.id || '';
  const defaultCycleId = activeCycles[0]?.id || cycles[0]?.id || '';
  const defaultAccountId = accounts[0]?.id || '';

  // Form states
  // 1. Expense Form
  const [expCategory, setExpCategory] = useState('electricity');
  const [expDescription, setExpDescription] = useState('');
  const [expAmount, setExpAmount] = useState<number | ''>('');
  const [expFarmId, setExpFarmId] = useState(defaultFarmId);
  const [expCycleId, setExpCycleId] = useState(defaultCycleId);
  const [expAccountId, setExpAccountId] = useState(defaultAccountId);
  const [expPaidAmount, setExpPaidAmount] = useState<number | ''>('');
  const [expPaymentMethod, setExpPaymentMethod] = useState<PaymentMethod>('cash');

  // 2. Sale Form
  const [saleCustomerId, setSaleCustomerId] = useState(partners.find(p => p.type === 'customer')?.id || '');
  const [saleFarmId, setSaleFarmId] = useState(defaultFarmId);
  const [saleCycleId, setSaleCycleId] = useState(defaultCycleId);
  const [saleCount, setSaleCount] = useState<number | ''>('');
  const [saleTotalWeight, setSaleTotalWeight] = useState<number | ''>('');
  const [salePricePerKg, setSalePricePerKg] = useState<number | ''>(18.5);
  const [salePaid, setSalePaid] = useState<number | ''>('');
  const [saleAccountId, setSaleAccountId] = useState(defaultAccountId);

  const selectedSaleSummary = allCycleSummaries.find(summary => summary.cycleId === saleCycleId);
  const suggestedSalePrice = selectedSaleSummary?.costPerKg
    ? Math.ceil((selectedSaleSummary.costPerKg * 1.2) * 4) / 4
    : 0;

  useEffect(() => {
    if (suggestedSalePrice > 0) setSalePricePerKg(suggestedSalePrice);
  }, [saleCycleId, suggestedSalePrice]);

  const saleAverageWeight = selectedSaleSummary?.averageBirdWeightKg
    || cycles.find(cycle => cycle.id === saleCycleId)?.targetWeightKg
    || 2.2;

  useEffect(() => {
    const weight = Number(saleTotalWeight);
    if (weight > 0 && saleAverageWeight > 0) {
      setSaleCount(Math.max(1, Math.round(weight / saleAverageWeight)));
    }
  }, [saleTotalWeight, saleCycleId, saleAverageWeight]);

  // 3. Feed Form
  const [feedSupplierId, setFeedSupplierId] = useState(partners.find(p => p.type === 'supplier')?.id || '');
  const [feedType, setFeedType] = useState<'starter' | 'grower' | 'finisher'>('grower');
  const [feedBrand, setFeedBrand] = useState('علف نمو مركب 50 كغ');
  const [feedQuantityKg, setFeedQuantityKg] = useState<number | ''>(5000);
  const [feedPricePerKg, setFeedPricePerKg] = useState<number | ''>(4.5);
  const [feedFarmId, setFeedFarmId] = useState(defaultFarmId);
  const [feedCycleId, setFeedCycleId] = useState(activeCycles.find(cycle => cycle.farmId === defaultFarmId)?.id || '');
  const [feedPaid, setFeedPaid] = useState<number | ''>(0);
  const [feedAccountId, setFeedAccountId] = useState(defaultAccountId);

  const feedCycles = cycles.filter(cycle => cycle.farmId === feedFarmId && cycle.status !== 'completed');

  // 4. Med Form
  const [medSupplierId, setMedSupplierId] = useState(partners.find(p => p.type === 'supplier')?.id || '');
  const [medName, setMedName] = useState('');
  const [medCategory, setMedCategory] = useState<'vaccine' | 'antibiotic' | 'vitamin' | 'disinfectant' | 'supplement'>('vitamin');
  const [medAmount, setMedAmount] = useState<number | ''>('');
  const [medQuantity, setMedQuantity] = useState<number | ''>(1);
  const [medUnit, setMedUnit] = useState('حصة');
  const [medPaid, setMedPaid] = useState<number | ''>('');
  const [medFarmId, setMedFarmId] = useState(defaultFarmId);
  const [medCycleId, setMedCycleId] = useState(defaultCycleId);
  const [medAccountId, setMedAccountId] = useState(defaultAccountId);
  const medCycles = cycles.filter(cycle => cycle.farmId === medFarmId && cycle.status !== 'completed');

  // 5. Customer Payment Collection
  const [collectCustomerId, setCollectCustomerId] = useState(partners.find(p => p.type === 'customer')?.id || '');
  const [collectAmount, setCollectAmount] = useState<number | ''>('');
  const [collectAccountId, setCollectAccountId] = useState(defaultAccountId);
  const [collectNotes, setCollectNotes] = useState('');

  // 6. Supplier Payment
  const [paySupplierId, setPaySupplierId] = useState(partners.find(p => p.type === 'supplier')?.id || '');
  const [payAmount, setPayAmount] = useState<number | ''>('');
  const [payAccountId, setPayAccountId] = useState(defaultAccountId);
  const [payNotes, setPayNotes] = useState('');

  // 7. Worker Payment / Advance
  const [wrkId, setWrkId] = useState(workers[0]?.id || '');
  const [wrkType, setWrkType] = useState<'salary' | 'advance_loan' | 'bonus'>('salary');
  const [wrkAmount, setWrkAmount] = useState<number | ''>('');
  const [wrkCycleId, setWrkCycleId] = useState(defaultCycleId);
  const [wrkAccountId, setWrkAccountId] = useState(defaultAccountId);
  const [wrkNotes, setWrkNotes] = useState('');
  const workerCycles = cycles.filter(cycle => cycle.status !== 'completed' && (!workers.find(worker => worker.id === wrkId)?.farmId || cycle.farmId === workers.find(worker => worker.id === wrkId)?.farmId));

  // 8. Mortality Log
  const [mortCycleId, setMortCycleId] = useState(defaultCycleId);
  const [mortDate, setMortDate] = useState(getMoroccoDateISO());
  const [mortCount, setMortCount] = useState<number | ''>('');
  const [mortFeedKg, setMortFeedKg] = useState<number | ''>('');
  const [mortMedicationPurchaseId, setMortMedicationPurchaseId] = useState('');
  const [mortMedicationName, setMortMedicationName] = useState('');
  const [mortMedicationQuantity, setMortMedicationQuantity] = useState<number | ''>('');
  const [mortMedicationUnit, setMortMedicationUnit] = useState('جرعة');
  const [mortNotes, setMortNotes] = useState('');
  const mortCycleFarmId = cycles.find(cycle => cycle.id === mortCycleId)?.farmId;
  const mortMedicationStock = medicationPurchases
    .filter(purchase => purchase.farmId === mortCycleFarmId)
    .map(purchase => {
      const used = dailyLogs.filter(log => log.medicationPurchaseId === purchase.id).reduce((sum, log) => sum + (log.medicationQuantity || 0), 0)
        + medicationMovements.filter(m => m.medicationPurchaseId === purchase.id && ['issue', 'waste'].includes(m.type)).reduce((sum, m) => sum + m.quantity, 0);
      return { purchase, available: Math.max(0, (purchase.quantity ?? 1) - used) };
    })
    .filter(item => item.available > 0);
  const selectedMortMedication = mortMedicationStock.find(item => item.purchase.id === mortMedicationPurchaseId);

  // 9. Weight Sample Log
  const [weightCycleId, setWeightCycleId] = useState(defaultCycleId);
  const [weightDate, setWeightDate] = useState(getMoroccoDateISO());
  const [sampleAvgGrams, setSampleAvgGrams] = useState<number | ''>('');
  const [weightNotes, setWeightNotes] = useState('');
  const mortalityDayNumber = getCycleDayNumber(cycles.find(c => c.id === mortCycleId)?.startDate || '', mortDate);
  const weightDayNumber = getCycleDayNumber(cycles.find(c => c.id === weightCycleId)?.startDate || '', weightDate);

  // 10. Account Transfer
  const [xferFromId, setXferFromId] = useState(accounts[0]?.id || '');
  const [xferToId, setXferToId] = useState(accounts[1]?.id || '');
  const [xferAmount, setXferAmount] = useState<number | ''>('');
  const [xferNotes, setXferNotes] = useState('');

  // 11. Chick Purchase
  const [chickSupplierId, setChickSupplierId] = useState(partners.find(p => p.type === 'supplier' || p.type === 'both')?.id || '');
  const [chickFarmId, setChickFarmId] = useState(defaultFarmId);
  const [chickCycleId, setChickCycleId] = useState(defaultCycleId);
  const [chickBreed, setChickBreed] = useState('Ross 308');
  const [chickCount, setChickCount] = useState<number | ''>('');
  const [chickUnitPrice, setChickUnitPrice] = useState<number | ''>(5.8);
  const [chickTransport, setChickTransport] = useState<number | ''>(0);
  const [chickVaccines, setChickVaccines] = useState<number | ''>(0);
  const [chickPaid, setChickPaid] = useState<number | ''>('');
  const [chickAccountId, setChickAccountId] = useState(defaultAccountId);
  const [chickNotes, setChickNotes] = useState('');

  if (!isOpen) return null;

  const triggerSuccess = (msg: string) => {
    try {
      confetti({ particleCount: 60, spread: 60, origin: { y: 0.7 } });
    } catch (_) {}
    setSuccessMessage(msg);
    setTimeout(() => {
      setSuccessMessage(null);
      onClose();
      setActiveAction('menu');
    }, 1200);
  };

  const actionList = [
    { id: 'expense', permission: 'canManagePurchases', label: 'مصروف جديد', sub: 'كهرباء، غاز، صيانة، فرشة...', icon: Receipt, color: 'from-amber-600 to-amber-500' },
    { id: 'sale', permission: 'canManageSales', label: 'بيع بالجملة', sub: 'تسجيل بيعة دجاج وزن وقبض', icon: ShoppingCart, color: 'from-emerald-600 to-emerald-500' },
    { id: 'collect', permission: 'canManageFinance', label: 'تحصيل من زبون', sub: 'قبض دين أو دفعة مؤجلة', icon: ArrowDownLeft, color: 'from-teal-600 to-teal-500' },
    { id: 'feed', permission: 'canManagePurchases', label: 'شراء علف', sub: 'بادي، نامي، ناهي مع المورد', icon: Wheat, color: 'from-amber-500 to-yellow-500' },
    { id: 'med', permission: 'canManagePurchases', label: 'شراء دواء/لقاح', sub: 'تحصينات ومضادات بيطرية', icon: Pill, color: 'from-indigo-600 to-indigo-500' },
    { id: 'chicks', permission: 'canManagePurchases', label: 'شراء كتاكيت', sub: 'العدد والسلالة والنقل واللقاحات', icon: Egg, color: 'from-orange-600 to-amber-500' },
    { id: 'supplier_pay', permission: 'canManageFinance', label: 'دفع لمورد', sub: 'سداد فواتير الأعلاف والأدوية', icon: ArrowUpRight, color: 'from-rose-600 to-rose-500' },
    { id: 'worker_pay', permission: 'canManageWorkers', label: 'دفع لعامل / سلفة', sub: 'رواتب وسلف ومكافآت العمال', icon: UserCheck, color: 'from-purple-600 to-purple-500' },
    { id: 'mortality', permission: 'canEnterDailyLogs', label: 'تسجيل نافق يومي', sub: 'توثيق عدد الوفيات والعلف', icon: Skull, color: 'from-stone-700 to-stone-600' },
    { id: 'weight', permission: 'canEnterDailyLogs', label: 'تسجيل وزن عينة', sub: 'متابعة النمو ومتوسط الوزن', icon: Scale, color: 'from-blue-600 to-blue-500' },
    { id: 'transfer', permission: 'canManageFinance', label: 'تحويل مالي', sub: 'بين البنوك والصناديق', icon: ArrowLeftRight, color: 'from-cyan-600 to-cyan-500' }
  ];

  // Submit Handlers
  const handleExpenseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expAmount || Number(expAmount) <= 0) return;
    const amt = Number(expAmount);
    const paid = expPaidAmount === '' ? amt : Number(expPaidAmount);
    addExpense({
      date: getMoroccoDateISO(),
      category: expCategory,
      description: expDescription || `مصروف ${expCategory}`,
      amount: amt,
      paidAmount: paid,
      remainingAmount: Math.max(0, amt - paid),
      farmId: expFarmId,
      cycleId: expCycleId || undefined,
      paymentMethod: expPaymentMethod,
      accountId: expAccountId
    });
    triggerSuccess('تم تسجيل المصروف بنجاح!');
  };

  const handleSaleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!saleCustomerId || !saleTotalWeight || !salePricePerKg || !saleCount) return;
    const count = Number(saleCount);
    const weight = Number(saleTotalWeight);
    const price = Number(salePricePerKg);
    const gross = weight * price;
    const net = gross;
    const paid = salePaid === '' ? net : Number(salePaid);
    const rem = Math.max(0, net - paid);

    addSale({
      invoiceNumber: `VTE-${Date.now().toString().slice(-4)}`,
      date: getMoroccoDateISO(),
      customerId: saleCustomerId,
      farmId: saleFarmId,
      cycleId: saleCycleId,
      chickenCount: count,
      totalWeightKg: weight,
      averageWeightKg: Number((weight / count).toFixed(3)),
      pricePerKg: price,
      grossTotal: gross,
      discount: 0,
      netTotal: net,
      paidAmount: paid,
      remainingAmount: rem,
      paymentMethod: rem > 0 ? 'partial' : 'cash',
      accountId: saleAccountId
    });
    triggerSuccess('تم تسجيل فاتورة البيع والقبض بنجاح!');
  };

  const handleFeedSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedFarmId || !feedQuantityKg || !feedPricePerKg) return;
    const qty = Number(feedQuantityKg);
    const unitPrice = Number(feedPricePerKg);
    const total = qty * unitPrice;
    const paid = feedPaid === '' ? 0 : Number(feedPaid);
    const rem = Math.max(0, total - paid);

    addFeedPurchase({
      invoiceNumber: `FAC-F-${Date.now().toString().slice(-4)}`,
      date: getMoroccoDateISO(),
      supplierId: feedSupplierId,
      feedType,
      brand: feedBrand,
      quantityKg: qty,
      bagsCount: Math.round(qty / 50),
      bagWeightKg: 50,
      unitPricePerKg: unitPrice,
      totalAmount: total,
      farmId: feedFarmId,
      cycleId: feedCycleId || undefined,
      paymentMethod: rem === 0 ? 'cash' : paid > 0 ? 'partial' : 'delayed',
      paidAmount: paid,
      remainingAmount: rem,
      accountId: feedAccountId
    });
    triggerSuccess('تم تسجيل شراء العلف وتحديث ديون المورد!');
  };

  const handleMedSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!medFarmId || !medAmount) return;
    const total = Number(medAmount);
    const paid = medPaid === '' ? total : Number(medPaid);
    const rem = Math.max(0, total - paid);

    addMedicationPurchase({
      date: getMoroccoDateISO(),
      supplierId: medSupplierId,
      medicationName: medName || 'أدوية وتحصينات بيطرية',
      category: medCategory,
      quantity: Number(medQuantity || 0),
      unit: medUnit,
      unitPrice: Number(medQuantity || 1) > 0 ? total / Number(medQuantity || 1) : total,
      totalAmount: total,
      farmId: medFarmId,
      cycleId: medCycleId || undefined,
      paymentMethod: rem === 0 ? 'cash' : 'partial',
      paidAmount: paid,
      remainingAmount: rem,
      accountId: medAccountId
    });
    triggerSuccess('تم تسجيل شراء الأدوية بنجاح!');
  };

  const handleChickSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chickCount || !chickUnitPrice || !chickSupplierId) return;
    const count = Number(chickCount);
    const chickCost = count * Number(chickUnitPrice);
    const total = chickCost + Number(chickTransport || 0) + Number(chickVaccines || 0);
    const paid = chickPaid === '' ? total : Math.min(total, Number(chickPaid));
    addChickPurchase({
      invoiceNumber: `CHK-${Date.now().toString().slice(-6)}`,
      date: getMoroccoDateISO(),
      supplierId: chickSupplierId,
      breed: chickBreed,
      farmId: chickFarmId,
      cycleId: chickCycleId || undefined,
      orderedCount: count,
      bonusCount: 0,
      transportMortalityCount: 0,
      receivedHealthyCount: count,
      unitPrice: Number(chickUnitPrice),
      chickCost,
      transportCost: Number(chickTransport || 0),
      vaccineCostAtHatchery: Number(chickVaccines || 0),
      totalAmount: total,
      paidAmount: paid,
      remainingAmount: total - paid,
      paymentMethod: paid === total ? 'cash' : paid > 0 ? 'partial' : 'delayed',
      accountId: chickAccountId,
      notes: chickNotes || undefined
    });
    triggerSuccess('تم تسجيل شراء الكتاكيت وتحديث مصاريف المورد!');
  };

  const handleCollectSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!collectAmount || Number(collectAmount) <= 0) return;
    addSettlementTransaction({
      partnerId: collectCustomerId,
      amount: Number(collectAmount),
      type: 'customer_payment',
      accountId: collectAccountId,
      description: collectNotes || 'تحصيل دفعة مالية من الزبون',
      paymentMethod: 'cash'
    });
    triggerSuccess('تم تسجيل التحصيل وتحديث رصيد الزبون!');
  };

  const handlePaySupplierSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payAmount || Number(payAmount) <= 0) return;
    addSettlementTransaction({
      partnerId: paySupplierId,
      amount: Number(payAmount),
      type: 'supplier_payment',
      accountId: payAccountId,
      description: payNotes || 'سداد دفعة للمورد',
      paymentMethod: 'bank_transfer'
    });
    triggerSuccess('تم سداد الدفعة للمورد وتخفيض الدين!');
  };

  const handleWorkerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!wrkAmount || Number(wrkAmount) <= 0) return;
    const worker = workers.find(w => w.id === wrkId);
    addWorkerTransaction({
      workerId: wrkId,
      farmId: worker?.farmId || defaultFarmId,
      cycleId: wrkCycleId,
      date: getMoroccoDateISO(),
      type: wrkType,
      amount: Number(wrkAmount),
      accountId: wrkAccountId,
      description: wrkNotes || (wrkType === 'salary' ? 'صرف راتب' : wrkType === 'advance_loan' ? 'سلفة على الراتب' : 'مكافأة')
    });
    triggerSuccess('تم تسجيل صرف المبلغ للعامل!');
  };

  const handleMortalitySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mortCount || mortalityDayNumber < 1) return;
    if (mortMedicationPurchaseId && (!selectedMortMedication || Number(mortMedicationQuantity || 0) <= 0 || Number(mortMedicationQuantity) > selectedMortMedication.available)) return;
    addDailyLog({
      cycleId: mortCycleId,
      date: mortDate,
      dayNumber: mortalityDayNumber,
      mortalityCount: Number(mortCount),
      feedConsumedKg: Number(mortFeedKg || 0),
      medicationPurchaseId: mortMedicationPurchaseId || undefined,
      medicationName: selectedMortMedication?.purchase.medicationName || mortMedicationName.trim() || undefined,
      medicationQuantity: mortMedicationQuantity ? Number(mortMedicationQuantity) : undefined,
      medicationUnit: selectedMortMedication?.purchase.unit || (mortMedicationName.trim() ? mortMedicationUnit : undefined),
      notes: mortNotes
    });
    triggerSuccess('تم تسجيل عدد النافق وتحديث سجل الدورة!');
  };

  const handleWeightSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sampleAvgGrams || weightDayNumber < 1) return;
    addDailyLog({
      cycleId: weightCycleId,
      date: weightDate,
      dayNumber: weightDayNumber,
      mortalityCount: 0,
      feedConsumedKg: 0,
      sampleAverageWeightGrams: Number(sampleAvgGrams),
      notes: weightNotes || 'عينة وزن دورية'
    });
    triggerSuccess('تم حفظ متوسط وزن العينة بنجاح!');
  };

  const handleTransferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!xferAmount || xferFromId === xferToId) return;
    addAccountTransfer(xferFromId, xferToId, Number(xferAmount), xferNotes);
    triggerSuccess('تم تحويل السيولة بين الحسابات بنجاح!');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4">
      <div className="fixed inset-0 bg-stone-950/80 backdrop-blur-sm" onClick={onClose} />

      <div className="relative w-full max-w-lg bg-stone-900 border border-stone-700 rounded-2xl shadow-2xl overflow-hidden z-10 max-h-[92vh] flex flex-col">
        {/* Modal Header */}
        <div className="p-4 bg-stone-800/90 border-b border-stone-700 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
              ⚡
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-stone-100">
                {activeAction === 'menu'
                  ? (language === 'ar' ? 'تسجيل عملية سريعة (< 10 ثوانٍ)' : 'Opération Rapide (< 10s)')
                  : actionList.find(a => a.id === activeAction)?.label}
              </h3>
              <p className="text-[11px] text-stone-400">
                {language === 'ar' ? 'اختر العملية ليتم حسابها مالياً وتشغيلياً تلقائياً' : 'Calcul automatique et synchronisé'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {activeAction !== 'menu' && (
              <button
                onClick={() => setActiveAction('menu')}
                className="text-xs text-amber-400 hover:text-amber-300 font-bold px-2 py-1 bg-stone-800 rounded-lg"
              >
                {language === 'ar' ? 'عودة' : 'Retour'}
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-stone-400 hover:text-stone-200 hover:bg-stone-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-4 overflow-y-auto flex-1">
          {successMessage ? (
            <div className="py-12 text-center space-y-3 animate-fade-in">
              <CheckCircle2 className="w-14 h-14 text-emerald-400 mx-auto" />
              <div className="text-base font-bold text-stone-100">{successMessage}</div>
              <p className="text-xs text-stone-400">تم تحديث الأرصدة والسجلات والـ Audit Log فوراً</p>
            </div>
          ) : activeAction === 'menu' ? (
            /* Action Menu Grid */
            <div className="grid grid-cols-2 gap-2.5">
              {actionList.filter(act => hasPermission(act.permission as keyof UserPermissions)).map((act) => {
                const Icon = act.icon;
                return (
                  <button
                    key={act.id}
                    onClick={() => setActiveAction(act.id)}
                    className="p-3 rounded-xl bg-stone-800/80 hover:bg-stone-700/80 border border-stone-700 text-right flex flex-col justify-between gap-2 transition active:scale-95 group"
                  >
                    <div className={`w-8 h-8 rounded-lg bg-gradient-to-tr ${act.color} text-white flex items-center justify-center shadow-md`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-bold text-xs text-stone-100 group-hover:text-amber-300 transition">
                        + {act.label}
                      </div>
                      <div className="text-[10px] text-stone-400 leading-tight line-clamp-1">
                        {act.sub}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          ) : (
            /* Sub-forms */
            <div>
              {/* 0. Chick Purchase Form */}
              {activeAction === 'chicks' && (
                <form onSubmit={handleChickSubmit} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-stone-300 font-bold mb-1">المفرخة / المورد *</label>
                    <select required value={chickSupplierId} onChange={e => setChickSupplierId(e.target.value)} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100">
                      <option value="">اختر المورد</option>
                      {partners.filter(p => p.type === 'supplier' || p.type === 'both').map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">مكان التخزين</label>
                      <select value={chickFarmId} onChange={e => { setChickFarmId(e.target.value); if (e.target.value === 'central') setChickCycleId(''); }} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100">
                        <option value="central">🏢 المخزن العام</option>
                        {farms.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">الدورة</label>
                      <select value={chickCycleId} onChange={e => setChickCycleId(e.target.value)} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100">
                        <option value="">بدون دورة</option>
                        {cycles.map(c => <option key={c.id} value={c.id}>{c.cycleNumber}</option>)}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">السلالة</label>
                      <select value={chickBreed} onChange={e => setChickBreed(e.target.value)} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100">
                        {CHICK_BREEDS.map(breed => <option key={breed}>{breed}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">عدد الكتاكيت *</label>
                      <input type="number" min="1" required value={chickCount} onChange={e => setChickCount(e.target.value === '' ? '' : Number(e.target.value))} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100 font-bold" />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div><label className="block text-stone-300 font-bold mb-1">سعر الكتكوت</label><input type="number" min="0" step="0.01" required value={chickUnitPrice} onChange={e => setChickUnitPrice(e.target.value === '' ? '' : Number(e.target.value))} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100" /></div>
                    <div><label className="block text-stone-300 font-bold mb-1">النقل</label><input type="number" min="0" value={chickTransport} onChange={e => setChickTransport(e.target.value === '' ? '' : Number(e.target.value))} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100" /></div>
                    <div><label className="block text-stone-300 font-bold mb-1">اللقاحات</label><input type="number" min="0" value={chickVaccines} onChange={e => setChickVaccines(e.target.value === '' ? '' : Number(e.target.value))} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100" /></div>
                  </div>

                  {chickCount && chickUnitPrice && <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 space-y-1">
                    <div className="flex justify-between"><span>قيمة الكتاكيت:</span><b>{(Number(chickCount) * Number(chickUnitPrice)).toLocaleString()} {currency}</b></div>
                    <div className="flex justify-between font-black text-amber-300"><span>الإجمالي:</span><b>{(Number(chickCount) * Number(chickUnitPrice) + Number(chickTransport || 0) + Number(chickVaccines || 0)).toLocaleString()} {currency}</b></div>
                  </div>}

                  <div className="grid grid-cols-2 gap-2">
                    <div><label className="block text-stone-300 font-bold mb-1">المدفوع الآن</label><input type="number" min="0" value={chickPaid} onChange={e => setChickPaid(e.target.value === '' ? '' : Number(e.target.value))} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-emerald-400 font-bold" /></div>
                    <div><label className="block text-stone-300 font-bold mb-1">حساب الدفع</label><select value={chickAccountId} onChange={e => setChickAccountId(e.target.value)} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100">{accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}</select></div>
                  </div>
                  <input type="text" placeholder="ملاحظات أو رقم الشحنة..." value={chickNotes} onChange={e => setChickNotes(e.target.value)} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100" />
                  <button type="submit" className="w-full py-2.5 bg-orange-500 hover:bg-orange-400 text-stone-950 font-extrabold rounded-xl shadow-md mt-2">تسجيل شراء الكتاكيت</button>
                </form>
              )}

              {/* 1. Quick Expense Form */}
              {activeAction === 'expense' && (
                <form onSubmit={handleExpenseSubmit} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-stone-300 font-bold mb-1">نوع المصروف</label>
                    <select
                      value={expCategory}
                      onChange={e => setExpCategory(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                    >
                      <option value="electricity">كهرباء وطاقة</option>
                      <option value="fuel">غاز ومحروقات التدفئة</option>
                      <option value="water">ماء وسقي</option>
                      <option value="cleaning_disinfection">فرشة نجارة وتطهير</option>
                      <option value="transport">نقل وتوصيل</option>
                      <option value="maintenance">صيانة وإصلاحات</option>
                      <option value="labor">عمالة مؤقتة ومياومين</option>
                      <option value="rent">إيجار المزرعة</option>
                      <option value="admin">مصاريف إدارية وهاتف</option>
                      <option value="other">مصاريف أخرى</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-stone-300 font-bold mb-1">المبلغ الإجمالي ({currency}) *</label>
                    <input
                      type="number"
                      required
                      placeholder="0.00"
                      value={expAmount}
                      onChange={e => {
                        const val = e.target.value === '' ? '' : Number(e.target.value);
                        setExpAmount(val);
                        setExpPaidAmount(val);
                      }}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2.5 text-base font-bold text-amber-400"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">المزرعة</label>
                      <select
                        value={expFarmId}
                        onChange={e => setExpFarmId(e.target.value)}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                      >
                        {farms.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">الدورة المرتبطة</label>
                      <select
                        value={expCycleId}
                        onChange={e => setExpCycleId(e.target.value)}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                      >
                        <option value="">بدون دورة (عام للمزرعة)</option>
                        {cycles.map(c => <option key={c.id} value={c.id}>{c.cycleNumber}</option>)}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">المدفوع حالياً</label>
                      <input
                        type="number"
                        value={expPaidAmount}
                        onChange={e => setExpPaidAmount(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100 font-semibold"
                      />
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">الحساب المالي للدفع</label>
                      <select
                        value={expAccountId}
                        onChange={e => setExpAccountId(e.target.value)}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                      >
                        {accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-stone-300 font-bold mb-1">بيان / ملاحظات</label>
                    <input
                      type="text"
                      placeholder="تفاصيل المصروف..."
                      value={expDescription}
                      onChange={e => setExpDescription(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-stone-950 font-extrabold rounded-xl shadow-md mt-2 transition"
                  >
                    حفظ المصروف
                  </button>
                </form>
              )}

              {/* 2. Quick Wholesale Sale Form */}
              {activeAction === 'sale' && (
                <form onSubmit={handleSaleSubmit} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-stone-300 font-bold mb-1">الزبون / المشتري *</label>
                    <select
                      required
                      value={saleCustomerId}
                      onChange={e => setSaleCustomerId(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                    >
                      {partners.filter(p => p.type === 'customer' || p.type === 'both').map(c => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">المزرعة</label>
                      <select
                        value={saleFarmId}
                        onChange={e => setSaleFarmId(e.target.value)}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                      >
                        {farms.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">الدورة المباعة</label>
                      <select
                        value={saleCycleId}
                        onChange={e => setSaleCycleId(e.target.value)}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100 font-semibold text-amber-300"
                      >
                        {cycles.map(c => <option key={c.id} value={c.id}>{c.cycleNumber}</option>)}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">عدد الدجاج (تقديري)</label>
                      <input
                        type="number"
                        required
                        placeholder="2500"
                        value={saleCount}
                        onChange={e => setSaleCount(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100 font-bold"
                      />
                      <p className="text-[10px] text-stone-500 mt-1">يُحسب تلقائيًا من الوزن ÷ {saleAverageWeight.toFixed(2)} كغ متوسط الطائر</p>
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">الوزن الإجمالي (كغ)</label>
                      <input
                        type="number"
                        step="0.1"
                        required
                        placeholder="5400"
                        value={saleTotalWeight}
                        onChange={e => setSaleTotalWeight(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100 font-bold"
                      />
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">سعر الكيلو ({currency})</label>
                      <input
                        type="number"
                        step="0.1"
                        required
                        value={salePricePerKg}
                        onChange={e => setSalePricePerKg(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100 font-bold text-amber-400"
                      />
                      {suggestedSalePrice > 0 && (
                        <p className="text-[10px] text-emerald-300 mt-1">
                          المقترح لهذه الدورة: {suggestedSalePrice.toFixed(2)} {currency}/كغ — التعادل: {selectedSaleSummary?.costPerKg.toFixed(2)} {currency}
                        </p>
                      )}
                    </div>
                  </div>

                  {saleTotalWeight && salePricePerKg && (
                    <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between">
                      <span className="text-stone-300 font-bold">إجمالي الفاتورة:</span>
                      <span className="text-base font-extrabold text-amber-300">
                        {(Number(saleTotalWeight) * Number(salePricePerKg)).toLocaleString()} {currency}
                      </span>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">المبلغ المقبوض حالياً</label>
                      <input
                        type="number"
                        placeholder="المبلغ المدفوع..."
                        value={salePaid}
                        onChange={e => setSalePaid(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100 font-semibold text-emerald-400"
                      />
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">إيداع في حساب</label>
                      <select
                        value={saleAccountId}
                        onChange={e => setSaleAccountId(e.target.value)}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                      >
                        {accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                      </select>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold rounded-xl shadow-md mt-2 transition"
                  >
                    تسجيل البيعة وتحديث الذمم
                  </button>
                </form>
              )}

              {/* 3. Feed Purchase Form */}
              {activeAction === 'feed' && (
                <form onSubmit={handleFeedSubmit} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-stone-300 font-bold mb-1">شركة الأعلاف / المورد</label>
                    <select
                      value={feedSupplierId}
                      onChange={e => setFeedSupplierId(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                    >
                      {partners.filter(p => p.type === 'supplier' || p.type === 'both').map(s => (
                        <option key={s.id} value={s.id}>{s.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">مكان التخزين</label>
                      <select
                        required
                        value={feedFarmId}
                        onChange={e => {
                          const farmId = e.target.value;
                          setFeedFarmId(farmId);
                          setFeedCycleId('');
                        }}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                      >
                        <option value="">اختر مكان التخزين</option>
                        <option value="central">🏢 المخزن العام</option>
                        {farms.filter(farm => isFarmAllowed(farm.id)).map(farm => <option key={farm.id} value={farm.id}>{farm.name}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">نوع العلف</label>
                      <select
                        value={feedType}
                        onChange={e => setFeedType(e.target.value as any)}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                      >
                        <option value="starter">بادي (Starter 21%)</option>
                        <option value="grower">نامي (Grower 19%)</option>
                        <option value="finisher">ناهي (Finisher 17%)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">الدورة المستفيدة (اختياري)</label>
                      <select
                        value={feedCycleId}
                        onChange={e => setFeedCycleId(e.target.value)}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                      >
                        <option value="">مخزن المزرعة العام</option>
                        {feedCycles.map(c => <option key={c.id} value={c.id}>{c.cycleNumber}</option>)}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">الكمية الإجمالية (كغ)</label>
                      <input
                        type="number"
                        required
                        value={feedQuantityKg}
                        onChange={e => setFeedQuantityKg(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100 font-bold"
                      />
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">سعر الكيلو ({currency})</label>
                      <input
                        type="number"
                        step="0.05"
                        required
                        value={feedPricePerKg}
                        onChange={e => setFeedPricePerKg(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100 font-bold text-amber-400"
                      />
                    </div>
                  </div>

                  {feedQuantityKg && feedPricePerKg && (
                    <div className="p-2.5 rounded-xl bg-stone-800 border border-stone-700 flex items-center justify-between">
                      <span className="text-stone-300">الإجمالي:</span>
                      <span className="font-extrabold text-amber-400">
                        {(Number(feedQuantityKg) * Number(feedPricePerKg)).toLocaleString()} {currency}
                      </span>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">المدفوع فوراً</label>
                      <input
                        type="number"
                        placeholder="0.00"
                        value={feedPaid}
                        onChange={e => setFeedPaid(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100 font-semibold"
                      />
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">طريقة الدفع</label>
                      <select
                        value={feedAccountId}
                        onChange={e => setFeedAccountId(e.target.value)}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                      >
                        {accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                      </select>
                    </div>
                  </div>

                  <p className="text-[11px] text-amber-400/80">
                    💡 المبلغ المتبقي يسجل تلقائياً كدين للمورد ويظهر في الذمم المالية.
                  </p>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-stone-950 font-extrabold rounded-xl shadow-md transition"
                  >
                    حفظ فاتورة العلف وتحديث المخزون
                  </button>
                </form>
              )}

              {/* 4. Customer Collection Form */}
              {activeAction === 'collect' && (
                <form onSubmit={handleCollectSubmit} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-stone-300 font-bold mb-1">اختر الزبون</label>
                    <select
                      value={collectCustomerId}
                      onChange={e => setCollectCustomerId(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                    >
                      {partners.filter(p => p.type === 'customer' || p.type === 'both').map(c => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-stone-300 font-bold mb-1">المبلغ المحصل ({currency}) *</label>
                    <input
                      type="number"
                      required
                      placeholder="0.00"
                      value={collectAmount}
                      onChange={e => setCollectAmount(e.target.value === '' ? '' : Number(e.target.value))}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2.5 text-base font-bold text-emerald-400"
                    />
                  </div>

                  <div>
                    <label className="block text-stone-300 font-bold mb-1">إيداع في الصندوق / الحساب</label>
                    <select
                      value={collectAccountId}
                      onChange={e => setCollectAccountId(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                    >
                      {accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                    </select>
                  </div>

                  <div>
                    <label className="block text-stone-300 font-bold mb-1">بيان / رقم الشيك / ملاحظات</label>
                    <input
                      type="text"
                      placeholder="دفعة شيك أو نقداً..."
                      value={collectNotes}
                      onChange={e => setCollectNotes(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-teal-600 hover:bg-teal-500 text-white font-extrabold rounded-xl shadow-md transition"
                  >
                    تأكيد التحصيل وتخفيض دين الزبون
                  </button>
                </form>
              )}

              {/* 5. Supplier Payment Form */}
              {activeAction === 'supplier_pay' && (
                <form onSubmit={handlePaySupplierSubmit} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-stone-300 font-bold mb-1">اختر المورد / الشركة</label>
                    <select
                      value={paySupplierId}
                      onChange={e => setPaySupplierId(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                    >
                      {partners.filter(p => p.type === 'supplier' || p.type === 'both').map(s => (
                        <option key={s.id} value={s.id}>{s.name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-stone-300 font-bold mb-1">المبلغ المسدد للمورد ({currency}) *</label>
                    <input
                      type="number"
                      required
                      placeholder="0.00"
                      value={payAmount}
                      onChange={e => setPayAmount(e.target.value === '' ? '' : Number(e.target.value))}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2.5 text-base font-bold text-rose-400"
                    />
                  </div>

                  <div>
                    <label className="block text-stone-300 font-bold mb-1">السحب من حساب</label>
                    <select
                      value={payAccountId}
                      onChange={e => setPayAccountId(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                    >
                      {accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                    </select>
                  </div>

                  <div>
                    <label className="block text-stone-300 font-bold mb-1">بيان / رقم الحوالة</label>
                    <input
                      type="text"
                      placeholder="رقم الشيك أو الحوالة البنكية..."
                      value={payNotes}
                      onChange={e => setPayNotes(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-extrabold rounded-xl shadow-md transition"
                  >
                    تأكيد السداد وتخفيض الدين
                  </button>
                </form>
              )}

              {/* 6. Worker Payment */}
              {activeAction === 'worker_pay' && (
                <form onSubmit={handleWorkerSubmit} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-stone-300 font-bold mb-1">العامل</label>
                    <select
                      value={wrkId}
                      onChange={e => setWrkId(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                    >
                      {workers.map(w => <option key={w.id} value={w.id}>{w.name} ({w.jobTitle})</option>)}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">نوع الحركة</label>
                      <select
                        value={wrkType}
                        onChange={e => setWrkType(e.target.value as any)}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                      >
                        <option value="salary">أجرة / راتب شهري</option>
                        <option value="advance_loan">سلفة (تسبيق)</option>
                        <option value="bonus">مكافأة نجاح الدورة</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">المبلغ ({currency})</label>
                      <input
                        type="number"
                        required
                        value={wrkAmount}
                        onChange={e => setWrkAmount(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100 font-bold"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-stone-300 font-bold mb-1">الدورة المرتبطة *</label>
                    <select
                      required
                      value={wrkCycleId}
                      onChange={e => setWrkCycleId(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100 font-semibold text-amber-300"
                    >
                      <option value="">اختر الدورة</option>
                      {workerCycles.map(cycle => <option key={cycle.id} value={cycle.id}>{cycle.cycleNumber} — {cycle.startDate}</option>)}
                    </select>
                    <p className="text-[10px] text-stone-500 mt-1">ستظهر الأجرة أو السلفة ضمن تكاليف الدورة وتقاريرها.</p>
                  </div>

                  <div>
                    <label className="block text-stone-300 font-bold mb-1">الصندوق / الحساب المالي</label>
                    <select
                      value={wrkAccountId}
                      onChange={e => setWrkAccountId(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                    >
                      {accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-extrabold rounded-xl shadow-md transition"
                  >
                    تسجيل الدفع للعامل
                  </button>
                </form>
              )}

              {/* 7. Mortality Daily Log */}
              {activeAction === 'mortality' && (
                <form onSubmit={handleMortalitySubmit} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-stone-300 font-bold mb-1">الدورة الحالية</label>
                    <select
                      value={mortCycleId}
                      onChange={e => setMortCycleId(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100 font-semibold text-amber-300"
                    >
                      {cycles.map(c => <option key={c.id} value={c.id}>{c.cycleNumber}</option>)}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-2 items-end">
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">تاريخ العملية *</label>
                      <input type="date" required min={cycles.find(c => c.id === mortCycleId)?.startDate} value={mortDate} onChange={e => setMortDate(e.target.value)} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100" />
                    </div>
                    <div className="rounded-lg bg-amber-500/10 border border-amber-500/30 p-2 text-amber-200 font-bold">
                      رقم اليوم المحسوب: {mortalityDayNumber > 0 ? `اليوم ${mortalityDayNumber}` : 'تاريخ قبل بداية الدورة'}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">عدد الطيور النافقة اليوم *</label>
                      <input
                        type="number"
                        required
                        placeholder="0"
                        value={mortCount}
                        onChange={e => setMortCount(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2.5 text-base font-bold text-rose-400"
                      />
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">استهلاك العلف اليوم (كغ)</label>
                      <input
                        type="number"
                        placeholder="2200"
                        value={mortFeedKg}
                        onChange={e => setMortFeedKg(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2.5 text-base font-bold text-amber-300"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 rounded-xl border border-indigo-500/20 bg-indigo-500/5 p-3">
                    <div className="sm:col-span-2">
                      <label className="block text-stone-300 font-bold mb-1">الدواء / اللقاح من مخزون المزرعة</label>
                      <select value={mortMedicationPurchaseId} onChange={e => { setMortMedicationPurchaseId(e.target.value); setMortMedicationName(''); }} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100">
                        <option value="">بدون دواء / لقاح</option>
                        {mortMedicationStock.map(item => <option key={item.purchase.id} value={item.purchase.id}>{item.purchase.medicationName} — متاح {item.available} {item.purchase.unit || 'وحدة'}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">الكمية والوحدة</label>
                      <div className="flex gap-1">
                        <input type="number" min="0.01" max={selectedMortMedication?.available} placeholder="0" value={mortMedicationQuantity} onChange={e => setMortMedicationQuantity(e.target.value === '' ? '' : Number(e.target.value))} className="w-full min-w-0 bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100" />
                        <select value={selectedMortMedication?.purchase.unit || mortMedicationUnit} onChange={e => setMortMedicationUnit(e.target.value)} disabled={!!selectedMortMedication} className="w-20 bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100">
                          <option>جرعة</option><option>مل</option><option>لتر</option><option>غ</option><option>كغ</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-stone-300 font-bold mb-1">ملاحظات بيطرية أو حرارة</label>
                    <input
                      type="text"
                      placeholder="حالة الفرشة، التهوية، الحرارة..."
                      value={mortNotes}
                      onChange={e => setMortNotes(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-stone-700 hover:bg-stone-600 text-white font-extrabold rounded-xl shadow-md transition"
                  >
                    حفظ السجل اليومي
                  </button>
                </form>
              )}

              {/* 8. Weight Sample Log */}
              {activeAction === 'weight' && (
                <form onSubmit={handleWeightSubmit} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-stone-300 font-bold mb-1">الدورة</label>
                    <select
                      value={weightCycleId}
                      onChange={e => setWeightCycleId(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                    >
                      {cycles.map(c => <option key={c.id} value={c.id}>{c.cycleNumber}</option>)}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-2 items-end">
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">تاريخ العملية *</label>
                      <input type="date" required min={cycles.find(c => c.id === weightCycleId)?.startDate} value={weightDate} onChange={e => setWeightDate(e.target.value)} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100" />
                    </div>
                    <div className="rounded-lg bg-blue-500/10 border border-blue-500/30 p-2 text-blue-200 font-bold">
                      رقم اليوم المحسوب: {weightDayNumber > 0 ? `اليوم ${weightDayNumber}` : 'تاريخ قبل بداية الدورة'}
                    </div>
                  </div>

                  <div>
                    <label className="block text-stone-300 font-bold mb-1">متوسط وزن الطائر في العينة (بالغرام) *</label>
                    <input
                      type="number"
                      required
                      placeholder="مثال: 1450 غرام"
                      value={sampleAvgGrams}
                      onChange={e => setSampleAvgGrams(e.target.value === '' ? '' : Number(e.target.value))}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2.5 text-base font-bold text-blue-400"
                    />
                  </div>

                  <div>
                    <label className="block text-stone-300 font-bold mb-1">ملاحظات العينة</label>
                    <input
                      type="text"
                      placeholder="عينة 50 طائر من وسط العنبر..."
                      value={weightNotes}
                      onChange={e => setWeightNotes(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-extrabold rounded-xl shadow-md transition"
                  >
                    تسجيل الوزن وتحديث منحنى النمو
                  </button>
                </form>
              )}

              {/* 9. Account Transfer */}
              {activeAction === 'transfer' && (
                <form onSubmit={handleTransferSubmit} className="space-y-3 text-xs">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">من حساب (المصدر)</label>
                      <select
                        value={xferFromId}
                        onChange={e => setXferFromId(e.target.value)}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                      >
                        {accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">إلى حساب (المستلم)</label>
                      <select
                        value={xferToId}
                        onChange={e => setXferToId(e.target.value)}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                      >
                        {accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-stone-300 font-bold mb-1">المبلغ المحول ({currency}) *</label>
                    <input
                      type="number"
                      required
                      placeholder="0.00"
                      value={xferAmount}
                      onChange={e => setXferAmount(e.target.value === '' ? '' : Number(e.target.value))}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2.5 text-base font-bold text-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="block text-stone-300 font-bold mb-1">السبب / ملاحظات</label>
                    <input
                      type="text"
                      placeholder="تغذية الصندوق، تحويل بنكي..."
                      value={xferNotes}
                      onChange={e => setXferNotes(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-extrabold rounded-xl shadow-md transition"
                  >
                    تأكيد التحويل المالي
                  </button>
                </form>
              )}

              {/* 10. Medication Purchase Form */}
              {activeAction === 'med' && (
                <form onSubmit={handleMedSubmit} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-stone-300 font-bold mb-1">المورد البيطري</label>
                    <select
                      value={medSupplierId}
                      onChange={e => setMedSupplierId(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                    >
                      {partners.filter(p => p.type === 'supplier' || p.type === 'both').map(s => (
                        <option key={s.id} value={s.id}>{s.name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-stone-300 font-bold mb-1">اسم الدواء / اللقاح *</label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: لقاح نيوكاسل، فيتامين C، مضاد كوكسيديا..."
                      value={medName}
                      onChange={e => setMedName(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">مكان التخزين</label>
                      <select
                        required
                        value={medFarmId}
                        onChange={e => {
                          setMedFarmId(e.target.value);
                          setMedCycleId('');
                        }}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                      >
                        <option value="">اختر مكان التخزين</option>
                        <option value="central">🏢 المخزن العام</option>
                        {farms.filter(farm => isFarmAllowed(farm.id)).map(farm => <option key={farm.id} value={farm.id}>{farm.name}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">النوع</label>
                      <select
                        value={medCategory}
                        onChange={e => setMedCategory(e.target.value as any)}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                      >
                        <option value="vaccine">لقاح وتحصين</option>
                        <option value="antibiotic">مضاد حيوي</option>
                        <option value="vitamin">فيتامينات ومكملات</option>
                        <option value="disinfectant">مطهر ومعقم</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">الدورة المرتبطة (اختياري)</label>
                      <select
                        value={medCycleId}
                        onChange={e => setMedCycleId(e.target.value)}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                      >
                        <option value="">مخزن المزرعة العام</option>
                        {medCycles.map(c => <option key={c.id} value={c.id}>{c.cycleNumber}</option>)}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">الكمية والوحدة في المخزون *</label>
                      <div className="flex gap-1"><input type="number" min="0.01" step="0.01" required value={medQuantity} onChange={e => setMedQuantity(e.target.value === '' ? '' : Number(e.target.value))} className="w-full min-w-0 bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100" /><select value={medUnit} onChange={e => setMedUnit(e.target.value)} className="w-20 bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"><option>حصة</option><option>لتر</option><option>مل</option><option>كغ</option><option>غ</option><option>قرص</option><option>جرعة</option></select></div>
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">المبلغ الإجمالي ({currency})</label>
                      <input
                        type="number"
                        required
                        value={medAmount}
                        onChange={e => {
                          const val = e.target.value === '' ? '' : Number(e.target.value);
                          setMedAmount(val);
                          setMedPaid(val);
                        }}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100 font-bold"
                      />
                    </div>
                    <div>
                      <label className="block text-stone-300 font-bold mb-1">المدفوع حالياً</label>
                      <input
                        type="number"
                        value={medPaid}
                        onChange={e => setMedPaid(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-stone-300 font-bold mb-1">الحساب المالي</label>
                    <select
                      value={medAccountId}
                      onChange={e => setMedAccountId(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"
                    >
                      {accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold rounded-xl shadow-md transition"
                  >
                    حفظ فاتورة الأدوية
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
