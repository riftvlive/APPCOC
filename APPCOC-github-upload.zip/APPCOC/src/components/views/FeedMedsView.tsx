import React, { useState } from 'react';
import {
  Wheat,
  Pill,
  Plus,
  Calendar,
  DollarSign,
  TrendingDown,
  Building2,
  Warehouse,
  FileText,
  CheckCircle2,
  AlertCircle,
  Printer
} from 'lucide-react';
import { useFarm } from '../../context/FarmContext';
import { getMoroccoDateISO } from '../../utils/date';

interface FeedMedsViewProps {
  onOpenQuickAction: (action?: string) => void;
}

export const FeedMedsView: React.FC<FeedMedsViewProps> = ({ onOpenQuickAction }) => {
  const {
    feedPurchases,
    feedMovements,
    dailyLogs,
    medicationPurchases,
    medicationMovements,
    partners,
    cycles,
    farms,
    currency,
    language,
    selectedFarmId,
    addFeedMovement,
    addFeedTransfer,
    addMedicationMovement,
    canEnterDailyLogs,
    isFarmAllowed,
    currentUser
  } = useFarm();

  const [activeTab, setActiveTab] = useState<'feed' | 'meds'>('feed');
  const [movementOpen, setMovementOpen] = useState(false);
  const [movementType, setMovementType] = useState<'issue' | 'return' | 'waste' | 'transfer' | 'opening'>('issue');
  const [movementDate, setMovementDate] = useState(getMoroccoDateISO());
  const [movementFarmId, setMovementFarmId] = useState(selectedFarmId === 'all' ? farms.find(f => isFarmAllowed(f.id))?.id || '' : selectedFarmId);
  const [movementDestinationFarmId, setMovementDestinationFarmId] = useState('');
  const [movementCycleId, setMovementCycleId] = useState('');
  const [movementSourcePurchaseId, setMovementSourcePurchaseId] = useState('');
  const [movementQuantity, setMovementQuantity] = useState<number | ''>('');
  const [movementNotes, setMovementNotes] = useState('');
  const [movementError, setMovementError] = useState('');
  const [medMovementOpen, setMedMovementOpen] = useState(false);
  const [medMovementType, setMedMovementType] = useState<'issue' | 'return' | 'waste'>('issue');
  const [medMovementDate, setMedMovementDate] = useState(getMoroccoDateISO());
  const [medMovementFarmId, setMedMovementFarmId] = useState(selectedFarmId === 'all' ? farms.find(f => isFarmAllowed(f.id))?.id || '' : selectedFarmId);
  const [medMovementPurchaseId, setMedMovementPurchaseId] = useState('');
  const [medMovementCycleId, setMedMovementCycleId] = useState('');
  const [medMovementQuantity, setMedMovementQuantity] = useState<number | ''>('');
  const [medMovementNotes, setMedMovementNotes] = useState('');
  const [medMovementError, setMedMovementError] = useState('');

  const filteredFeeds = selectedFarmId === 'all'
    ? feedPurchases
    : feedPurchases.filter(f => f.farmId === selectedFarmId);

  const filteredMeds = selectedFarmId === 'all'
    ? medicationPurchases
    : medicationPurchases.filter(m => m.farmId === selectedFarmId);

  const totalFeedKg = filteredFeeds.reduce((sum, f) => sum + f.quantityKg, 0);
  const totalFeedCost = filteredFeeds.reduce((sum, f) => sum + f.totalAmount, 0);
  const totalMedCost = filteredMeds.reduce((sum, m) => sum + m.totalAmount, 0);
  const medStockItems = filteredMeds.map(purchase => {
    const movements = medicationMovements.filter(m => m.medicationPurchaseId === purchase.id);
    const received = movements.filter(m => ['purchase', 'opening', 'return'].includes(m.type)).reduce((sum, m) => sum + m.quantity, 0);
    const issued = movements.filter(m => ['issue', 'waste'].includes(m.type)).reduce((sum, m) => sum + m.quantity, 0);
    return { purchase, available: Math.max(0, (received || purchase.quantity || 1) - issued) };
  });
  const selectedMedSource = medStockItems.find(item => item.purchase.id === medMovementPurchaseId);
  const medMovementCycles = cycles.filter(c => c.farmId === medMovementFarmId && c.status !== 'completed');

  const handleMedicationMovementSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    const quantity = Number(medMovementQuantity || 0);
    setMedMovementError('');
    if (!medMovementFarmId || !medMovementPurchaseId || quantity <= 0) return setMedMovementError('اختر المزرعة والدواء وأدخل كمية صحيحة.');
    if (medMovementType === 'issue' && !medMovementCycleId) return setMedMovementError('اختر الدورة المستفيدة من الدواء.');
    if (selectedMedSource && quantity > selectedMedSource.available) return setMedMovementError(`الكمية تتجاوز الرصيد المتاح (${selectedMedSource.available} ${selectedMedSource.purchase.unit || 'وحدة'}).`);
    const purchase = selectedMedSource?.purchase;
    if (!purchase) return;
    addMedicationMovement({ date: medMovementDate, type: medMovementType, medicationPurchaseId: purchase.id, medicationName: purchase.medicationName, quantity, unit: purchase.unit || 'وحدة', unitCost: purchase.unitPrice || purchase.totalAmount / Math.max(1, purchase.quantity || 1), totalCost: quantity * (purchase.unitPrice || purchase.totalAmount / Math.max(1, purchase.quantity || 1)), farmId: medMovementFarmId, cycleId: medMovementType === 'issue' ? medMovementCycleId : undefined, notes: medMovementNotes || undefined });
    setMedMovementOpen(false);
    setMedMovementQuantity('');
    setMedMovementNotes('');
    setMedMovementPurchaseId('');
    setMedMovementCycleId('');
  };
  const scopedFarmIds = new Set((selectedFarmId === 'all' ? farms : farms.filter(f => f.id === selectedFarmId)).map(f => f.id));
  const movementPurchaseIds = new Set(feedMovements.map(m => m.sourcePurchaseId).filter(Boolean));
  const legacyPurchasedKg = filteredFeeds
    .filter(feed => !movementPurchaseIds.has(feed.id))
    .reduce((sum, feed) => sum + feed.quantityKg, 0);
  const movementInKg = feedMovements
    .filter(m => scopedFarmIds.has(m.farmId) && ['purchase', 'opening', 'transfer_in', 'return'].includes(m.type))
    .reduce((sum, movement) => sum + movement.quantityKg, 0);
  const movementOutKg = feedMovements
    .filter(m => scopedFarmIds.has(m.farmId) && ['issue', 'transfer_out', 'waste'].includes(m.type))
    .reduce((sum, movement) => sum + movement.quantityKg, 0);
  const movementLogIds = new Set(feedMovements.filter(m => m.dailyLogId).map(m => m.dailyLogId));
  const legacyConsumedKg = dailyLogs
    .filter(log => !movementLogIds.has(log.id) && cycles.some(c => c.id === log.cycleId && scopedFarmIds.has(c.farmId)))
    .reduce((sum, log) => sum + Math.max(0, log.feedConsumedKg || 0), 0);
  const totalFeedStockKg = Math.max(0, legacyPurchasedKg + movementInKg - movementOutKg - legacyConsumedKg);
  const movementFarmStockKg = Math.max(0, feedPurchases.filter(f => f.farmId === movementFarmId).reduce((sum, f) => sum + f.quantityKg, 0)
    + feedMovements.filter(m => m.farmId === movementFarmId && ['opening', 'transfer_in', 'return'].includes(m.type)).reduce((sum, m) => sum + m.quantityKg, 0)
    - feedMovements.filter(m => m.farmId === movementFarmId && ['issue', 'transfer_out', 'waste'].includes(m.type)).reduce((sum, m) => sum + m.quantityKg, 0)
    - dailyLogs.filter(l => !movementLogIds.has(l.id) && cycles.some(c => c.id === l.cycleId && c.farmId === movementFarmId)).reduce((sum, l) => sum + Math.max(0, l.feedConsumedKg || 0), 0));
  const movementCycles = cycles.filter(c => c.farmId === movementFarmId && c.status !== 'completed');
  const movementSources = feedPurchases.filter(f => f.farmId === movementFarmId);
  const selectedMovementSource = movementSources.find(p => p.id === movementSourcePurchaseId);
  const visibleFeedMovements = feedMovements
    .filter(m => scopedFarmIds.has(m.farmId))
    .sort((a, b) => b.date.localeCompare(a.date));
  const visibleMedicationMovements = medicationMovements
    .filter(m => scopedFarmIds.has(m.farmId))
    .sort((a, b) => b.date.localeCompare(a.date));
  const movementLabel = (type: string) => ({
    purchase: 'شراء / دخول', opening: 'رصيد افتتاحي', issue: 'صرف للدورة',
    return: 'مرتجع للمخزن', waste: 'هدر / تلف', transfer: 'تحويل',
    transfer_in: 'تحويل وارد', transfer_out: 'تحويل صادر', adjustment: 'تسوية'
  }[type] || type);
  const getSourceRemainingKg = (purchaseId: string) => {
    const purchase = feedPurchases.find(feed => feed.id === purchaseId);
    if (!purchase) return 0;
    const related = feedMovements.filter(m => m.sourcePurchaseId === purchaseId);
    const received = related
      .filter(m => ['purchase', 'transfer_in', 'return'].includes(m.type))
      .reduce((sum, m) => sum + Math.max(0, m.quantityKg || 0), 0);
    const issued = related
      .filter(m => ['issue', 'transfer_out', 'waste'].includes(m.type))
      .reduce((sum, m) => sum + Math.max(0, m.quantityKg || 0), 0);
    return Math.max(0, (received || purchase.quantityKg) - issued);
  };

  const handleMovementSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    const quantityKg = Number(movementQuantity || 0);
    setMovementError('');
    if (!movementFarmId || quantityKg <= 0) {
      setMovementError('اختر المزرعة وأدخل كمية صحيحة أكبر من صفر.');
      return;
    }
    if (['issue', 'transfer'].includes(movementType) && quantityKg > movementFarmStockKg) {
      setMovementError(`الكمية تتجاوز رصيد المخزن المتاح (${movementFarmStockKg.toLocaleString()} كغ).`);
      return;
    }
    const source = movementSources.find(p => p.id === movementSourcePurchaseId);
    const sourceRemainingKg = source ? getSourceRemainingKg(source.id) : 0;
    if (source && ['issue', 'transfer', 'waste'].includes(movementType) && quantityKg > sourceRemainingKg) {
      setMovementError(`الكمية تتجاوز المتبقي من الفاتورة (${sourceRemainingKg.toLocaleString()} كغ).`);
      return;
    }
    const cycle = movementCycles.find(c => c.id === movementCycleId);
    if (movementType === 'transfer') {
      if (!movementDestinationFarmId || movementDestinationFarmId === movementFarmId) {
        setMovementError('اختر مزرعة مستقبلة مختلفة عن مزرعة المصدر.');
        return;
      }
      addFeedTransfer({ date: movementDate, quantityKg, feedType: source?.feedType, brand: source?.brand, sourceFarmId: movementFarmId, destinationFarmId: movementDestinationFarmId, sourcePurchaseId: movementSourcePurchaseId || undefined, unitCostPerKg: source?.unitPricePerKg, totalCost: source ? quantityKg * source.unitPricePerKg : undefined, notes: movementNotes || undefined });
    } else {
    addFeedMovement({
      date: movementDate,
      type: movementType,
      quantityKg,
      feedType: source?.feedType,
      brand: source?.brand,
      farmId: movementFarmId,
      cycleId: movementType === 'issue' ? movementCycleId || undefined : undefined,
      barnNumber: movementType === 'issue' ? cycle?.barnNumber : undefined,
      sourcePurchaseId: movementSourcePurchaseId || undefined,
      unitCostPerKg: source?.unitPricePerKg,
      totalCost: source ? quantityKg * source.unitPricePerKg : undefined,
      notes: movementNotes || undefined
    });
    }
    setMovementOpen(false);
    setMovementQuantity('');
    setMovementNotes('');
    setMovementCycleId('');
    setMovementSourcePurchaseId('');
    setMovementDestinationFarmId('');
    setMovementError('');
  };

  return (
    <div className="space-y-5 animate-fade-in pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-stone-900 border border-stone-800 rounded-2xl p-4 sm:p-5 no-print">
        <div>
          <div className="flex items-center gap-2">
            <Wheat className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-black text-stone-100">
              {language === 'ar' ? 'إدارة الأعلاف والأدوية واللقاحات' : 'Gestion des Aliments & Santé'}
            </h2>
          </div>
          <p className="text-xs text-stone-400 mt-1">
            {language === 'ar'
              ? 'متابعة مشتريات الأعلاف المركبة، كلفة الطن، استهلاك العنابر، والأدوية البيطرية'
              : 'Achats d’aliments, vaccins, antibiotiques et suivi des stocks'}
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={() => window.print()}
            className="flex-1 sm:flex-none px-3.5 py-2.5 bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition"
            title="طباعة تقرير المشتريات والمخزون"
          >
            <Printer className="w-4 h-4 text-amber-400" />
            <span>طباعة التقرير</span>
          </button>
          <button
            onClick={() => onOpenQuickAction('feed')}
            className="flex-1 sm:flex-none px-3.5 py-2.5 bg-amber-500 hover:bg-amber-400 text-stone-950 font-extrabold text-xs rounded-xl shadow flex items-center justify-center gap-1.5 transition"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>+ شراء علف</span>
          </button>
          {canEnterDailyLogs && <button
            onClick={() => setMovementOpen(true)}
            className="flex-1 sm:flex-none px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow flex items-center justify-center gap-1.5 transition"
          >
            <Warehouse className="w-4 h-4" />
            <span>حركة مخزون</span>
          </button>}
          <button
            onClick={() => onOpenQuickAction('med')}
            className="flex-1 sm:flex-none px-3.5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow flex items-center justify-center gap-1.5 transition"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>+ شراء دواء</span>
          </button>
        </div>
      </div>

      {/* Official Print Header */}
      <div className="print-only border-b-2 border-stone-800 pb-3 mb-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-black text-stone-900">
              تقرير مشتريات واستهلاك الأعلاف والأدوية البيطرية
            </h1>
            <p className="text-xs text-stone-600">
              مزارعنا لإدارة مزارع الدواجن • تاريخ الاستخراج: {new Date().toLocaleDateString('ar-MA')} - {new Date().toLocaleTimeString('ar-MA', { hour: '2-digit', minute: '2-digit' })}
            </p>
          </div>
          <div className="text-left text-xs text-stone-700 font-semibold">
            <div>إجمالي كمية العلف: {(totalFeedKg / 1000).toFixed(1)} طن ({totalFeedCost.toLocaleString()} {currency})</div>
            <div>إجمالي الأدوية واللقاحات: {totalMedCost.toLocaleString()} {currency}</div>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4">
          <div className="flex items-center gap-2 text-stone-400 text-xs mb-1 font-semibold">
            <Wheat className="w-4 h-4 text-amber-400" />
            <span>إجمالي كمية العلف المشتراة</span>
          </div>
          <div className="text-xl font-black text-amber-300">
            {(totalFeedKg / 1000).toFixed(1)} <span className="text-xs font-semibold text-stone-400">طن ({Math.round(totalFeedKg / 50)} كيس)</span>
          </div>
        </div>

        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4">
          <div className="flex items-center gap-2 text-stone-400 text-xs mb-1 font-semibold">
            <DollarSign className="w-4 h-4 text-amber-400" />
            <span>إجمالي تكلفة العلف</span>
          </div>
          <div className="text-xl font-black text-stone-100">
            {totalFeedCost.toLocaleString()} <span className="text-xs font-semibold text-stone-400">{currency}</span>
          </div>
        </div>

        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4">
          <div className="flex items-center gap-2 text-stone-400 text-xs mb-1 font-semibold">
            <Pill className="w-4 h-4 text-indigo-400" />
            <span>إجمالي تكلفة الأدوية واللقاحات</span>
          </div>
          <div className="text-xl font-black text-indigo-300">
            {totalMedCost.toLocaleString()} <span className="text-xs font-semibold text-stone-400">{currency}</span>
          </div>
        </div>
      </div>

      <div className="bg-stone-900 border border-amber-500/20 rounded-2xl p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-xs font-extrabold text-stone-100">
            <Warehouse className="w-4 h-4 text-amber-400" />
            <span>مخزون العلف النظري في المزرعة</span>
          </div>
          <span className="text-[10px] text-stone-500">شراء + دخول − صرف − هدر</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center text-xs">
          <div className="rounded-xl bg-stone-950/60 border border-stone-800 p-2.5"><span className="block text-stone-500 text-[10px]">المشتريات</span><strong className="text-amber-300">{(legacyPurchasedKg + movementInKg).toLocaleString()} كغ</strong></div>
          <div className="rounded-xl bg-stone-950/60 border border-stone-800 p-2.5"><span className="block text-stone-500 text-[10px]">المصروف والهدر</span><strong className="text-rose-300">{(movementOutKg + legacyConsumedKg).toLocaleString()} كغ</strong></div>
          <div className="rounded-xl bg-stone-950/60 border border-stone-800 p-2.5"><span className="block text-stone-500 text-[10px]">الرصيد النظري</span><strong className="text-emerald-300">{totalFeedStockKg.toLocaleString()} كغ</strong></div>
          <div className="rounded-xl bg-stone-950/60 border border-stone-800 p-2.5"><span className="block text-stone-500 text-[10px]">حركات المخزون</span><strong className="text-stone-200">{feedMovements.filter(m => scopedFarmIds.has(m.farmId)).length}</strong></div>
        </div>
      </div>

      {/* Tabs Switcher */}
      <div className="flex items-center gap-2 border-b border-stone-800 pb-2">
        <button
          onClick={() => setActiveTab('feed')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            activeTab === 'feed'
              ? 'bg-amber-500 text-stone-950 shadow'
              : 'bg-stone-900 text-stone-400 hover:text-stone-200'
          }`}
        >
          <Wheat className="w-4 h-4" />
          <span>سجل مشتريات الأعلاف ({filteredFeeds.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('meds')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            activeTab === 'meds'
              ? 'bg-indigo-600 text-white shadow'
              : 'bg-stone-900 text-stone-400 hover:text-stone-200'
          }`}
        >
          <Pill className="w-4 h-4" />
          <span>سجل الأدوية والتحصينات ({filteredMeds.length})</span>
        </button>
      </div>

      {/* Tab 1: Feed Purchases List */}
      {activeTab === 'feed' && (
        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="border-b border-stone-800 text-stone-400 text-[11px]">
                  <th className="pb-3 font-bold">الفاتورة / التاريخ</th>
                  <th className="pb-3 font-bold">المورد / الشركة</th>
                  <th className="pb-3 font-bold">النوع والصنف</th>
                  <th className="pb-3 font-bold">الكمية (كغ / أكياس)</th>
                  <th className="pb-3 font-bold">سعر الكيلو</th>
                  <th className="pb-3 font-bold">المبلغ الإجمالي</th>
                  <th className="pb-3 font-bold">المدفوع والمتبقي</th>
                  <th className="pb-3 font-bold">المزرعة / الدورة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-800/60">
                {filteredFeeds.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-stone-500">
                      لا توجد فواتير أعلاف مسجلة.
                    </td>
                  </tr>
                ) : (
                  filteredFeeds.map(f => {
                    const supplier = partners.find(p => p.id === f.supplierId);
                    const farm = farms.find(fm => fm.id === f.farmId);
                    const cycle = cycles.find(c => c.id === f.cycleId);

                    return (
                      <tr key={f.id} className="hover:bg-stone-800/40 transition">
                        <td className="py-3">
                          <span className="font-bold text-stone-200 block">{f.invoiceNumber}</span>
                          <span className="text-[10px] text-stone-500">{f.date}</span>
                        </td>
                        <td className="py-3 font-semibold text-stone-300">
                          {supplier?.name || 'مورد غير محدد'}
                        </td>
                        <td className="py-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            f.feedType === 'starter' ? 'bg-blue-500/20 text-blue-300' :
                            f.feedType === 'grower' ? 'bg-amber-500/20 text-amber-300' :
                            'bg-emerald-500/20 text-emerald-300'
                          }`}>
                            {f.feedType === 'starter' ? 'بادي (Starter)' : f.feedType === 'grower' ? 'نامي (Grower)' : 'ناهي (Finisher)'}
                          </span>
                          <span className="text-[10px] text-stone-400 block mt-0.5">{f.brand}</span>
                        </td>
                        <td className="py-3 font-bold text-stone-100">
                          {f.quantityKg.toLocaleString()} كغ
                          <span className="text-[10px] text-stone-400 block font-normal">{f.bagsCount} كيس 50كغ</span>
                        </td>
                        <td className="py-3 text-amber-400 font-bold">
                          {f.unitPricePerKg.toFixed(2)} {currency}
                        </td>
                        <td className="py-3 font-black text-stone-100">
                          {f.totalAmount.toLocaleString()} {currency}
                        </td>
                        <td className="py-3">
                          <span className="text-emerald-400 font-bold block">{f.paidAmount.toLocaleString()} {currency}</span>
                          {f.remainingAmount > 0 && (
                            <span className="text-rose-400 text-[10px] font-semibold block">متبقي: {f.remainingAmount.toLocaleString()} {currency}</span>
                          )}
                        </td>
                        <td className="py-3 text-[11px] text-stone-400">
                          {farm?.name || ''}
                          {cycle && <span className="block text-amber-400/80 font-bold">{cycle.cycleNumber}</span>}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
          <div className="mt-5 border-t border-stone-800 pt-4">
            <div className="flex items-center justify-between mb-3">
              <div><h3 className="font-extrabold text-stone-100 flex items-center gap-2"><Warehouse className="w-4 h-4 text-emerald-400" /> حركات مخزون العلف</h3><p className="text-[10px] text-stone-500 mt-1">سجل الدخول والصرف والمرتجعات والهدر والتحويلات</p></div>
              <span className="text-[10px] text-stone-500">{visibleFeedMovements.length} حركة</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead><tr className="border-b border-stone-800 text-stone-400 text-[11px]"><th className="pb-2 font-bold">التاريخ</th><th className="pb-2 font-bold">الحركة</th><th className="pb-2 font-bold">النوع / المصدر</th><th className="pb-2 font-bold">الكمية</th><th className="pb-2 font-bold">المزرعة / الدورة</th><th className="pb-2 font-bold">صاحب الحركة</th><th className="pb-2 font-bold">الملاحظات</th></tr></thead>
                <tbody className="divide-y divide-stone-800/60">{visibleFeedMovements.length === 0 ? <tr><td colSpan={7} className="py-6 text-center text-stone-500">لا توجد حركات مخزون مسجلة.</td></tr> : visibleFeedMovements.map(m => { const farm = farms.find(f => f.id === m.farmId); const cycle = cycles.find(c => c.id === m.cycleId); const source = feedPurchases.find(p => p.id === m.sourcePurchaseId); return <tr key={m.id} className="hover:bg-stone-800/40"><td className="py-2 text-stone-400">{m.date}</td><td className="py-2"><span className={`px-2 py-1 rounded-lg font-bold ${['issue','transfer_out','waste'].includes(m.type) ? 'bg-rose-500/15 text-rose-300' : 'bg-emerald-500/15 text-emerald-300'}`}>{movementLabel(m.type)}</span></td><td className="py-2 text-stone-300">{m.feedType || source?.brand || '—'}{source && <span className="block text-[10px] text-stone-500">{source.invoiceNumber}</span>}</td><td className="py-2 font-black text-stone-100">{m.quantityKg.toLocaleString()} كغ{m.unitCostPerKg ? <span className="block text-[10px] text-stone-500">{m.totalCost?.toLocaleString() || (m.quantityKg * m.unitCostPerKg).toLocaleString()} DH</span> : null}</td><td className="py-2 text-stone-400">{farm?.name || '—'}{cycle && <span className="block text-amber-400/80 font-bold">{cycle.cycleNumber}</span>}</td><td className="py-2 text-stone-300 font-semibold">{m.performedBy || 'غير محدد'}</td><td className="py-2 text-stone-500 max-w-48">{m.notes || '—'}</td></tr>; })}</tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Medications List */}
      {activeTab === 'meds' && (
        <div className="space-y-4">
          <div className="bg-stone-900 border border-indigo-500/20 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div><h3 className="font-extrabold text-sm text-stone-100 flex items-center gap-2"><Warehouse className="w-4 h-4 text-indigo-400" /> مخزون الدواء واللقاح</h3><p className="text-[10px] text-stone-500 mt-1">شراء + دخول + مرتجع − صرف − هدر</p></div>
              <button type="button" onClick={() => setMedMovementOpen(true)} className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold">حركة مخزون الدواء</button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {medStockItems.length === 0 ? <div className="text-xs text-stone-500">لا توجد أدوية في مخزون المزارع المسموحة.</div> : medStockItems.map(item => <div key={item.purchase.id} className="rounded-xl bg-stone-950/60 border border-stone-800 p-3 flex items-center justify-between"><div><div className="font-bold text-stone-200">{item.purchase.medicationName}</div><div className="text-[10px] text-stone-500">{item.purchase.unit || 'وحدة'} • {item.purchase.unitPrice?.toLocaleString() || '—'} DH/وحدة</div></div><strong className="text-indigo-300">{item.available.toLocaleString()} {item.purchase.unit || 'وحدة'}</strong></div>)}
            </div>
          </div>
          <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="border-b border-stone-800 text-stone-400 text-[11px]">
                  <th className="pb-3 font-bold">التاريخ</th>
                  <th className="pb-3 font-bold">اسم الدواء / اللقاح</th>
                  <th className="pb-3 font-bold">التصنيف</th>
                  <th className="pb-3 font-bold">المورد البيطري</th>
                  <th className="pb-3 font-bold">المبلغ الإجمالي</th>
                  <th className="pb-3 font-bold">حالة الدفع</th>
                  <th className="pb-3 font-bold">المزرعة / الدورة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-800/60">
                {filteredMeds.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-stone-500">
                      لا توجد مشتريات أدوية مسجلة.
                    </td>
                  </tr>
                ) : (
                  filteredMeds.map(m => {
                    const supplier = partners.find(p => p.id === m.supplierId);
                    const farm = farms.find(fm => fm.id === m.farmId);
                    const cycle = cycles.find(c => c.id === m.cycleId);

                    return (
                      <tr key={m.id} className="hover:bg-stone-800/40 transition">
                        <td className="py-3 text-stone-400 font-semibold">{m.date}</td>
                        <td className="py-3 font-extrabold text-stone-100">{m.medicationName}</td>
                        <td className="py-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-500/20 text-indigo-300">
                            {m.category === 'vaccine' ? 'لقاح وتحصين' :
                             m.category === 'antibiotic' ? 'مضاد حيوي' :
                             m.category === 'vitamin' ? 'فيتامينات ومكملات' : 'مطهر ومعقم'}
                          </span>
                        </td>
                        <td className="py-3 text-stone-300 font-medium">{supplier?.name || '-'}</td>
                        <td className="py-3 font-black text-amber-300">{m.totalAmount.toLocaleString()} {currency}</td>
                        <td className="py-3">
                          <span className="text-emerald-400 font-bold block">{m.paidAmount.toLocaleString()} {currency}</span>
                          {m.remainingAmount > 0 && (
                            <span className="text-rose-400 text-[10px] font-semibold">متبقي: {m.remainingAmount.toLocaleString()} {currency}</span>
                          )}
                        </td>
                        <td className="py-3 text-[11px] text-stone-400">
                          {farm?.name || ''}
                          {cycle && <span className="block text-amber-400/80 font-bold">{cycle.cycleNumber}</span>}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
          <div className="mt-5 border-t border-stone-800 pt-4">
            <div className="flex items-center justify-between mb-3"><div><h3 className="font-extrabold text-stone-100 flex items-center gap-2"><Pill className="w-4 h-4 text-indigo-400" /> حركات مخزون الدواء واللقاح</h3><p className="text-[10px] text-stone-500 mt-1">الكمية والقيمة المالية لكل صرف أو مرتجع أو هدر</p></div><span className="text-[10px] text-stone-500">{visibleMedicationMovements.length} حركة</span></div>
            <div className="overflow-x-auto"><table className="w-full text-right text-xs"><thead><tr className="border-b border-stone-800 text-stone-400 text-[11px]"><th className="pb-2 font-bold">التاريخ</th><th className="pb-2 font-bold">الحركة</th><th className="pb-2 font-bold">الدواء / اللقاح</th><th className="pb-2 font-bold">الكمية والقيمة</th><th className="pb-2 font-bold">المزرعة / الدورة</th><th className="pb-2 font-bold">صاحب الحركة</th><th className="pb-2 font-bold">الملاحظات</th></tr></thead><tbody className="divide-y divide-stone-800/60">{visibleMedicationMovements.length === 0 ? <tr><td colSpan={7} className="py-6 text-center text-stone-500">لا توجد حركات دواء مسجلة.</td></tr> : visibleMedicationMovements.map(m => { const farm=farms.find(f=>f.id===m.farmId); const cycle=cycles.find(c=>c.id===m.cycleId); return <tr key={m.id} className="hover:bg-stone-800/40"><td className="py-2 text-stone-400">{m.date}</td><td className="py-2"><span className={`px-2 py-1 rounded-lg font-bold ${['issue','waste'].includes(m.type) ? 'bg-rose-500/15 text-rose-300' : 'bg-emerald-500/15 text-emerald-300'}`}>{movementLabel(m.type)}</span></td><td className="py-2 font-bold text-stone-200">{m.medicationName || '—'}</td><td className="py-2 font-black text-indigo-300">{m.quantity.toLocaleString()} {m.unit}<span className="block text-[10px] text-stone-500">{(m.totalCost || 0).toLocaleString()} DH</span></td><td className="py-2 text-stone-400">{farm?.name || '—'}{cycle && <span className="block text-amber-400/80 font-bold">{cycle.cycleNumber}</span>}</td><td className="py-2 text-stone-300 font-semibold">{m.performedBy || 'غير محدد'}</td><td className="py-2 text-stone-500 max-w-48">{m.notes || '—'}</td></tr>; })}</tbody></table></div>
          </div>
          </div>
        </div>
      )}
      {medMovementOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/80 backdrop-blur-sm no-print">
          <form onSubmit={handleMedicationMovementSubmit} className="w-full max-w-lg bg-stone-900 border border-stone-700 rounded-2xl shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between"><h3 className="font-black text-stone-100">تسجيل حركة مخزون الدواء واللقاح</h3><button type="button" onClick={() => setMedMovementOpen(false)} className="text-stone-400 text-xl">×</button></div>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <label className="space-y-1"><span className="block text-stone-300 font-bold">نوع الحركة</span><select value={medMovementType} onChange={e => setMedMovementType(e.target.value as typeof medMovementType)} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"><option value="issue">صرف للدورة</option><option value="return">مرتجع للمخزن</option><option value="waste">هدر/تلف</option></select></label>
              <label className="space-y-1"><span className="block text-stone-300 font-bold">التاريخ</span><input type="date" required value={medMovementDate} onChange={e => setMedMovementDate(e.target.value)} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100" /></label>
              <label className="space-y-1"><span className="block text-stone-300 font-bold">المزرعة</span><select required value={medMovementFarmId} onChange={e => { setMedMovementFarmId(e.target.value); setMedMovementPurchaseId(''); setMedMovementCycleId(''); }} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100">{farms.filter(f => isFarmAllowed(f.id)).map(f => <option key={f.id} value={f.id}>{f.name}</option>)}</select></label>
              <label className="space-y-1 col-span-2"><span className="block text-stone-300 font-bold">مصدر الدواء / اللقاح</span><select required value={medMovementPurchaseId} onChange={e => setMedMovementPurchaseId(e.target.value)} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"><option value="">اختر من المخزون</option>{medicationPurchases.filter(p => p.farmId === medMovementFarmId).map(p => { const item = medStockItems.find(i => i.purchase.id === p.id); return <option key={p.id} value={p.id}>{p.medicationName} — {item?.available || 0} {p.unit || 'وحدة'}</option>; })}</select></label>
              {medMovementType === 'issue' && <label className="space-y-1 col-span-2"><span className="block text-stone-300 font-bold">الدورة المستفيدة</span><select required value={medMovementCycleId} onChange={e => setMedMovementCycleId(e.target.value)} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"><option value="">اختر الدورة</option>{medMovementCycles.map(c => <option key={c.id} value={c.id}>{c.cycleNumber}</option>)}</select></label>}
              <label className="space-y-1"><span className="block text-stone-300 font-bold">الكمية ({selectedMedSource?.purchase.unit || 'الوحدة'})</span><input type="number" min="0.01" step="0.01" required max={selectedMedSource?.available} value={medMovementQuantity} onChange={e => setMedMovementQuantity(e.target.value === '' ? '' : Number(e.target.value))} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100 font-bold" /></label>
              <div className="rounded-lg bg-stone-950/60 border border-stone-800 p-2 text-xs text-stone-400">القيمة المستهلكة<br /><strong className="text-indigo-300">{selectedMedSource && medMovementQuantity ? (Number(medMovementQuantity) * (selectedMedSource.purchase.unitPrice || selectedMedSource.purchase.totalAmount / Math.max(1, selectedMedSource.purchase.quantity || 1))).toLocaleString() : '0'} DH</strong></div>
            </div>
            {medMovementError && <div role="alert" className="rounded-lg border border-rose-800/70 bg-rose-950/40 p-2 text-xs font-bold text-rose-300">{medMovementError}</div>}
            <textarea value={medMovementNotes} onChange={e => setMedMovementNotes(e.target.value)} placeholder="ملاحظات الحركة (اختياري)" className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-xs text-stone-100 min-h-16" />
            <div className="flex gap-2"><button type="button" onClick={() => setMedMovementOpen(false)} className="flex-1 py-2 rounded-xl bg-stone-800 text-stone-300 font-bold text-xs">إلغاء</button><button type="submit" className="flex-1 py-2 rounded-xl bg-indigo-600 text-white font-black text-xs">حفظ الحركة</button></div>
          </form>
        </div>
      )}
      {movementOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/80 backdrop-blur-sm no-print">
          <form onSubmit={handleMovementSubmit} className="w-full max-w-lg bg-stone-900 border border-stone-700 rounded-2xl shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-black text-stone-100">تسجيل حركة مخزون العلف</h3>
              <button type="button" onClick={() => setMovementOpen(false)} className="text-stone-400 text-xl">×</button>
            </div>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <label className="space-y-1"><span className="block text-stone-300 font-bold">نوع الحركة</span><select value={movementType} onChange={e => setMovementType(e.target.value as typeof movementType)} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"><option value="issue">صرف للدورة</option><option value="return">مرتجع للمخزن</option><option value="waste">هدر/منسكب</option>{(currentUser.role === 'admin' || currentUser.role === 'farm_manager') && <option value="transfer">تحويل بين المزارع</option>}{currentUser.role === 'admin' && <option value="opening">رصيد افتتاحي</option>}</select></label>
              <label className="space-y-1"><span className="block text-stone-300 font-bold">التاريخ</span><input type="date" required value={movementDate} onChange={e => setMovementDate(e.target.value)} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100" /></label>
              <label className="space-y-1"><span className="block text-stone-300 font-bold">مصدر الحركة</span><select required value={movementFarmId} onChange={e => { setMovementFarmId(e.target.value); setMovementCycleId(''); }} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"><option value="central">🏢 المخزن العام</option>{farms.filter(f => isFarmAllowed(f.id)).map(f => <option key={f.id} value={f.id}>{f.name}</option>)}</select></label>
              <label className="space-y-1"><span className="block text-stone-300 font-bold">الكمية (كغ)</span><input type="number" min="0.01" step="0.01" required value={movementQuantity} onChange={e => setMovementQuantity(e.target.value === '' ? '' : Number(e.target.value))} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100 font-bold" /></label>
              {movementType === 'issue' && <label className="space-y-1"><span className="block text-stone-300 font-bold">الدورة/العنبر</span><select required value={movementCycleId} onChange={e => setMovementCycleId(e.target.value)} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"><option value="">اختر الدورة</option>{movementCycles.map(c => <option key={c.id} value={c.id}>{c.cycleNumber} {c.barnNumber ? `— عنبر ${c.barnNumber}` : ''}</option>)}</select></label>}
              {movementType === 'transfer' && <label className="space-y-1"><span className="block text-stone-300 font-bold">المزرعة المستقبلة</span><select required value={movementDestinationFarmId} onChange={e => setMovementDestinationFarmId(e.target.value)} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"><option value="">اختر المزرعة</option>{farms.filter(f => isFarmAllowed(f.id) && f.id !== movementFarmId).map(f => <option key={f.id} value={f.id}>{f.name}</option>)}</select></label>}
              <label className="space-y-1"><span className="block text-stone-300 font-bold">مصدر العلف</span><select value={movementSourcePurchaseId} onChange={e => { setMovementSourcePurchaseId(e.target.value); setMovementError(''); }} className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-stone-100"><option value="">اختياري / رصيد افتتاحي</option>{movementSources.map(p => <option key={p.id} value={p.id}>{p.invoiceNumber || p.id} — {p.brand} (متبقي {getSourceRemainingKg(p.id).toLocaleString()} كغ)</option>)}</select></label>
            </div>
            <div className="rounded-lg bg-stone-950/60 border border-stone-800 p-2 text-xs text-stone-400">الرصيد المتاح للمزرعة: <strong className="text-emerald-300">{movementFarmStockKg.toLocaleString()} كغ</strong>{selectedMovementSource && <span className="block mt-1">المتبقي من المصدر المحدد: <strong className="text-amber-300">{getSourceRemainingKg(selectedMovementSource.id).toLocaleString()} كغ</strong></span>}</div>
            {movementError && <div role="alert" className="rounded-lg border border-rose-800/70 bg-rose-950/40 p-2 text-xs font-bold text-rose-300">{movementError}</div>}
            <textarea value={movementNotes} onChange={e => setMovementNotes(e.target.value)} placeholder="ملاحظات الحركة (اختياري)" className="w-full bg-stone-800 border border-stone-700 rounded-lg p-2 text-xs text-stone-100 min-h-16" />
            <div className="flex gap-2"><button type="button" onClick={() => setMovementOpen(false)} className="flex-1 py-2 rounded-xl bg-stone-800 text-stone-300 font-bold text-xs">إلغاء</button><button type="submit" className="flex-1 py-2 rounded-xl bg-amber-500 text-stone-950 font-black text-xs">حفظ الحركة</button></div>
          </form>
        </div>
      )}
      {/* Official Print Footer */}
      <div className="print-only pt-8 mt-6 border-t-2 border-stone-300">
        <div className="flex items-center justify-between text-xs text-stone-700">
          <div>
            <span className="font-bold block">أمين المخزن والتموين:</span>
            <div className="h-10 border-b border-dashed border-stone-400 w-48 mt-1"></div>
          </div>
          <div>
            <span className="font-bold block">مصادقة الإدارة العامة:</span>
            <div className="h-10 border-b border-dashed border-stone-400 w-48 mt-1"></div>
          </div>
        </div>
      </div>
    </div>
  );
};
